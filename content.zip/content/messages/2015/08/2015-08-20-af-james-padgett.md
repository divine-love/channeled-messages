---
message_id: 2015-08-20-af-james-padgett
title: "Express the Truth to Others: Padgett Talks of Why This Is So Important"
date: 2015-08-20
spirit_name: James Padgett
spirit_id: james-padgett
medium: Al Fike
location:
  city: Gibsons
  region: BC
  country: Canada
gathering: "August 2015 Gibsons Retreat"
message_type: ["Teaching"]
description: "James Padgett speaks to the retreat gathering, reflecting on his own journey of doubt and fear as he received the Divine Love messages, and encouraging those present to walk boldly in the Truth as he could not always do himself. He assures them that the blessings of God's Love are infinite and exponential, and that even the smallest act of sharing the Truth can have great and enduring consequences for others."
primary_subjects: "Padgett Messages & Legacy"
secondary_subjects: ["Testimony of God's Love", "Discipleship", "Soul Spheres & Progression", "Spiritual Empowerment & Encouragement"]
people: []
spirits: ["jesus"]
keywords: ["Padgett", "automatic writing", "Padgett Messages", "Divine Love", "truth", "doubt", "fear", "courage", "testimony", "service", "spirit communication", "rewards", "celestial kingdom", "eternity", "commitment"]
questions:
  - "Who was James Padgett?"
  - "What are the Padgett Messages?"
  - "How were the Divine Love messages received through automatic writing?"
  - "Did James Padgett doubt the messages he received?"
  - "What rewards await those who share the Truth of Divine Love?"
  - "How do I share the Truth of Divine Love with others?"
  - "What happens in the spirit world to those who live and share God's Love?"
  - "How do I overcome fear of what others think about my spiritual beliefs?"
  - "Can one person sharing a spiritual truth really change the world?"
  - "What is the Celestial Kingdom?"
  - "How does the journey of spiritual growth continue after death?"
  - "What is the legacy of the Padgett Messages today?"
related_messages: []
audio_url: ""
canonical_url: "https://divinelovesanctuary.com/express-the-truth-to-others-padgett-talks-of-why-this-is-so-important/"
significance: ["Historical", "Biographical"]
notes: "James Padgett speaks at the August 2015 international retreat. He reflects on his own struggles with doubt and fear during his years as medium, and expresses gratitude that his work has borne fruit in the lives of those gathered."
last_edited: 2026-04-13
---

Beloved souls, I am Padgett, James Padgett. I have been asked to speak to you and it is my honor and privilege to do so in this gathering of beautiful souls. The Light that you have created by your presence and prayers is tremendous. It reverberates far out into the spheres of spirit. It creates a place where many spirits are drawn and seek the Light. You do a great service, my friends, in your prayers, in your efforts to reach the highest, to reach for God's Love.

Many of you know me and some do not know of me. Many years ago I was used by spirit to communicate the Truths of the Divine Love, to bring them into our era in a clear and understandable way, written through automatic writing. And I produced through the help of spirit many, many pages of information. And these pages exist still today and have been copied and printed and collated into volumes of books that are available to those who ask and desire to receive and read in order to further their knowledge of soul growth and the laws pertaining to Divine Love and the laws pertaining to the worlds of spirit and the worlds of the Celestial Kingdom.

These places exist as most of you know. God exists as all of you know. The power of His Love is the highest blessing you can receive and I am so grateful to have been able to give these messages to the world. And it was a struggle for me, my friends, to accept what is written, to allow these spirits to write many passages which I questioned. It took me some years to believe that what was being written was true. Yet I continued and persisted, I prayed for God's Love to enter into my soul and in this, I grew to accept the Truth, and then I grew to love the Truth, and then I grew to love my brothers and sisters because I came to a place of true understanding of our Heavenly Father. And now as I reside in this place, which is in spirit in the Celestial Kingdom, I continue to long and seek for Truth, for Love, for enlightenment, to truly know my soul, to truly know my Heavenly Father.

So you see my friends, this journey goes on. Do not condemn yourselves if you feel you have not come up to your expectations upon this Path, for you have all of eternity, my dear beloved friends, to truly know and understand, to be in God's Grace. And this short life on Earth is but a stepping stone to greater life and greater understanding of Love and Truth and God. And you, my beloved friends, are so blessed to have the angels with you, to have God's Hand upon you. You have drawn this to you by your pursuit and prayers for the Love. You have walked this road and persisted. You have struggled. You have prayed and prayed and prayed and the rewards, my dear and beloved friends, are coming, your blessings have been many, which shall increase and increase, they shall double and quadruple. It shall go on exponentially as you accept and live the Truth. The abundance of God's blessings is far beyond your capacity to understand for it is as infinite as the universe, as powerful as anything you know in your lives. And as you grow in this Love your perceptions will grow, your understanding of Truth will change, you will walk a path of great discovery uncovering many secrets which God will give to you in the flow of His Love.

Do not waste your time, my beloveds. Do not waste your time, but pray fervently for this Love to transform your souls and bring you into that great flow of God's Love. There is no greater pursuit, no greater rewards, no greater opportunity in your lives but this, this wondrous gift and all that comes with it. The opportunity to be of service to your Heavenly Father, the opportunity to love your brothers and sisters in the flow of God's Love. Take your time and pray. Make this the focus of your efforts spiritually. Seek the peace that passes all understanding. Open yourselves to this Love.

And though I wrote many pages, thousands upon thousands of words upon these pages given through me by spirit, the Truth is ultimately simple and wordless. What was written is a map, a way to help you in your thoughts, in your desires to come to God, to inspire you, to show you that this is true and real and powerful. And the testimony of this Truth is your presence here today, coming together from many far off places being together in Love, wanting to uphold one another and to be close to God. And you will bring the Truth, as you leave this place, back with you to where you live and God will give you opportunities to be His beautiful channels of Love. Many doors will open if you desire this.

Please continue to walk this Divine Path with all of us. I am pleased to see that my work has borne fruit, that others have come to this Truth and we all follow the Master Jesus upon this Path and gratefully so, for he leads us to greater heights of spiritual joy and awareness, of our souls bursting with Love – such joy, such knowing, such being in the Light. Continue on my brothers and sisters, continue with your great efforts and we shall continue to support you and we are pleased that others have used their gifts to bring Truth into the world. This is important, to continue to keep this channel of communication open between us in spirit and you in this world. For through this world we are able to communicate with many other layers of existence in spirit. Many come to listen to these words, many are here now.

So I say, one man who was filled with doubts and grief for the loss of his wife embarked upon a journey which has touched all of your lives. Such a simple act and decision has great consequences in the world. Consider this, my friends, consider this. That the choices that you make, the decisions in your lives can have great and wondrous consequences for the lives of others. And many await your commitment to live and bring the Truth to this world. Many possibilities await you, much love resides within you. And this is what is required, the Love of God burning within your souls. It empowers the journey and reverberates out into this world and where you put your focus, where you walk, how you are, will have great and enduring consequences for others for this world.

You have been guided that this world needs you and needs to change and go on a course that will lead to healing and harmony in this world. Consider my friends what you may do in service, how you may be in Love, where you may go to teach the Truth. And once you have entreated your Heavenly Father to guide you along where you are meant to go and how you are meant to be and who you are meant to meet, the journey will truly begin. For you have all taken your inner journeys, you have all worked diligently to repair your souls through Love, to prepare your minds through reading of the Truths. You are ready to walk out into the world guided by God and to be shown the way.

Are you ready to commit to this, to walk in this Light, to be that channel of Love and Truth which God has asked you to be? When I started on this Earth I was not sure of my steps. I was afraid. I was afraid of what others thought of me. I was fearful for my career, my reputation, my standing in the community because to hold up the Truth in this way is unusual. Eyebrows were raised, thoughts of judgment in many. Yet I persisted, and I must confess that my fears held me back to some degree. I did not want others to truly know what I was doing. But thanks to the efforts of braver souls, those who were willing to carry this torch, you today have heard of and know of and pray for the Truth of God's Love in a conscious and clear way. So you see, even I, who was not so committed, made an impact in this world. And you, my beloveds, who I see are stronger than myself, can make a greater impact in the world.

The world needs you. The world truly needs your efforts. The world truly needs the Truth. Can you walk boldly and say, Dear brothers and sisters, I have something that may change your life, a simple Truth so profound that it can change everything? You need not join a religion, an organization. It costs you nothing. It is freely given. Can you do this, to express the Truth so simply, to give so willingly, to walk so boldly? And yes many will turn away from you, will reject the gift that you have to give, but many will turn towards you and say yes, I am interested, I want to know of your gift. And each of those souls who truly come to understand and live the Truth of Love will be a jewel in your crown, and when that time comes for you to enter the world of spirit this will determine in many ways where you will go, the life that you will have in the life beyond. There are many rewards for the faithful. There are many rewards for those who choose Love, Divine Love over everything else. Those rewards in this Earth may not be so palpable, but believe me, when you enter into the world of spirit, you will be astounded at what will be given by God in gratitude for living the Truth and expressing the Truth, great rewards, wondrous blessings. I thank you, my friends, for the opportunity to speak to you and my heart grows large in gratitude and Love for those of you who have carried on this work. Thank you, thank you. And please continue, please work diligently and with Love. The rewards are awaiting you, my beloveds, and they are great. God bless you and keep you in His care. God bless you.