---
message_id: 2015-12-14-af-augustine
title: "Free Will versus God's Will"
date: 2015-12-14
spirit_id: augustine
spirit_name: Augustine
medium: Al Fike
location:
  city: Gibsons
  region: BC
  country: Canada
gathering:
message_type: ["Teaching"]
description: "Augustine teaches that the human mind alone cannot know God's Will, and that only a soul enlivened by Divine Love can perceive and align with it. He calls the circle to release mind-driven willfulness, seek the deeper consciousness of the soul, and become beacons of God's reality as the world stands on the verge of great change."
primary_subjects: "Free Will & Human Error"
secondary_subjects:
  - "Mind vs Soul Conflict"
  - "Divine Will, Guidance & Orchestration"
  - "Soul Awakening"
  - "Preparation for Earth Mission"
  - "Knowing God"
people: []
spirits: []
keywords: ["free will", "God's Will", "mind", "soul", "consciousness", "alignment", "willfulness", "truth", "transformation", "beacons", "change", "prayer", "soul gifts", "purpose", "reality"]
questions:
  - "What is the difference between my will and God's Will?"
  - "How do I know if I am following God's Will or my own?"
  - "Why can't the mind understand God's Will?"
  - "How does Divine Love help me know God's Will?"
  - "How do I move from living in my mind to living from my soul?"
  - "Why does the world seem so out of harmony with God?"
  - "How do I align my free will with God's plan?"
  - "What does it mean to let my soul inform my mind?"
  - "How do I prepare myself for the changes coming to the world?"
  - "How do I know my soul's purpose?"
  - "Can I truly know God's Will for me?"
related_messages:
  - 2015-12-07-af-augustine
  - 2015-09-27-af-augustine
  - 2015-08-03-af-augustine
audio_url: ""
canonical_url: "https://divinelovesanctuary.com/free-will-versus-gods-will/"
notes: "Possible transcription artifact: 'the answers that what they do in the world' — left as-is; may reflect spoken cadence."
significance: ["Key Teaching"]
language: en
excerpt: "You cannot know God's Will from your mind — the faculties of the mind were not gifted to mankind for this purpose. The faculties of the soul, enlivened by God's Touch of Love, are quite capable."
series: []
last_edited: 2026-04-17
---

God bless you beloveds, it is your teacher Augustine.

A lesson was given this morning which I wish to reiterate to all of you, my beloveds, for it is an important lesson regarding your free will and God's Will. For it is a tendency of mankind to formulate and to mold and to manipulate the flow of God's Will and Love in the world and to bring your ideas forward as to what this Love is, how it can be expressed and should be expressed in the world. And this is the great folly of mankind, which has led to many, many acts of error and has not brought God's Will effectively into the world, for it is contaminated by the will of each soul who assumes that they have the answers that what they do in the world, formulated, constructed and expressed through their minds is for the good of all. Many believe this is God's Will, and I tell you, my beloveds, you cannot know God's Will from your mind, for a mind that is not informed by the soul filled with God's Essence cannot possibly understand the Will of God. It is incapable. The faculties of the mind were not gifted to mankind for this purpose. The faculties of the soul, however, enlivened by God's Touch of Love are quite capable of understanding God's Will. And this we have implored upon you, my dear and beloved souls, to plumb the depths of your soul, to pray earnestly for this Gift of Love, so that you may know with great certainty and clarity God's Will for you and that you may know what God wishes for you to do in this world. For each soul is imbued with a great purpose which is reflected by the many Gifts which God has given you, my beloveds. And when you express these Gifts in harmony, when you allow your soul to inform your mind in a harmonious balance, then oh, what wondrous works of service, of manifesting Love, that of working in the harmonious flow of God's Will will be accomplished and expressed in beautiful and powerful ways.

Each of you is challenged, my beloveds, to put aside the willfulness of your minds and seek that other place of consciousness, awareness, of being that is your soul. This is challenging, for the world around you operates almost exclusively from that place of mind and you have created this reality within your own minds and collectively of the minds of all who live here in this world. Yet, is this the true reality, my beloveds? Is this God's reality? Is this God's Creation? No, my beloveds, it is not. It is the manifestation of the willfulness, the power of free will, the power of the mind to create reality, the power of all the choices made through the ages, creating this reality, this world. And does this world function in harmony? No, my beloveds. Are all loved, nurtured, cared for and embraced in peace and harmony? No, my beloveds. You walk in a place of deprivation. Though there is beauty, there is love, there are many aspects of this world that is filled with goodness, with a touch of Grace. And these, my beloveds, are the result of God's gift of creation and the result of mankind utilizing their Gifts, those parts naturally given within them to manifest in Light.

So I do not wish to condemn your world, merely to suggest that there could be so much more for all of you, for all mankind. And we have asked you, my beloveds, to seek, to grow, to shift, to come to understand the reality of God, so that you may be beacons, repositories of wisdom, of Truth, of Light, so that when the time comes for change, which is inevitable and imminent, to come to this world, you may teach others of the reality of God and show through your own examples and lives what that is, how that may be. And in this you do God a great service and give your brothers and sisters a great gift.

And you have been challenged, and called, and prepared, and nurtured, and loved and this shall continue to be so. Cradled in God's arms of Love, fed the Truth in simple but powerful ways, challenged to grow so that you may willingly learn the lessons required to shift your consciousness from that of the mundane, that which is of humanity to something higher, stronger, more beautiful, more loving. You stand on the verge of great change, my beloveds, it is coming and you must redouble your efforts in prayer. Walk your path to God, be resolute but joyful, be kind to yourselves but strong. Be clear with your truth yet humble and always, always act in love, my beloveds, act in love. For these simple acts carry great power and a message of Truth.

My dear beloved souls, you will continue to grow, to seek God's Love, to release all barriers to this Love, to absorb the Truth that comes with this Love, to shift within your consciousness and see the world, see yourselves, see your purpose, see that which is meaningful and true from a different place, from your souls. And this is happening, my beloveds, you can feel this, I know you can, we can feel the change within you, we perceive it, we see the Light growing within your beings and we see how God is touching you in powerful ways and helping you to release the old, to bring in the new, to be transformed and renewed.

Beloveds, we rejoice in these changes, in this growth, in your capacity to love and we walk with you, always by your side, always in the flow of God's Love. Beloveds, may you continue to walk in this Light, it is so important that you do so, and that you gather the souls who are seeking and eager, and you will do so and the doors will open. Yes, many are coming. God bless you, beloveds, your teacher Augustine loves you dearly. Thank you for listening to my words.