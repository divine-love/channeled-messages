---
message_id: 2016-07-10-af-augustine
title: "Nurturing the Mind or the Soul: It's a Choice"
date: 2016-07-10
spirit_id: augustine
spirit_name: Augustine
medium: Al Fike
location:
  city: Gibsons
  region: BC
  country: Canada
gathering:
message_type: ["Teaching"]
description: "Augustine delivers a comprehensive teaching on the soul's yearning as the true key to God, contrasting the mind's compulsion to rationalize and control with the soul's deeper capacity to receive Divine Truth. He traces the roots of human error to the mind's domination over the soul, charts both the natural love and Divine Love paths to their ultimate destinations, and urges each soul to plumb its own depths and follow the yearning that leads to at-onement with God."
primary_subjects: "Mind vs Soul Conflict"
secondary_subjects:
  - "Free Will & Human Error"
  - "Soul Awakening"
  - "Receiving the Divine Love through Prayer"
  - "At-onement"
people: []
spirits: []
keywords: ["yearning soul", "curious mind", "faith", "vulnerability", "armor", "longing", "at-onement", "soul perceptions", "mind dominance", "choice", "two paths", "religion", "materialism", "skepticism", "soul faculties"]
questions:
  - "Why does the mind get in the way of spiritual growth?"
  - "What is the difference between a yearning soul and a curious mind?"
  - "How do I access the deeper perceptions of my soul?"
  - "How do I step into the vulnerability of my soul without fear?"
  - "Why can't the mind understand spiritual truth?"
  - "What is the relationship between faith and the soul's yearning?"
  - "Where does the natural love path lead compared to the Divine Love path?"
  - "How do I know if I am feeding my mind or nurturing my soul?"
  - "Why do so many religions fail to bring the soul to at-onement?"
  - "How do I trust God enough to let Him into the deepest places within me?"
  - "What does it mean to serve my soul rather than my mind?"
  - "How does humanity's reverence for the mind contribute to error and suffering?"
  - "What blessings await those willing to journey inward with God?"
related_messages:
  - 2015-12-14-af-augustine
  - 2016-01-04-af-confucius
  - 2016-07-09-af-confucius
  - 2016-06-13-af-james
audio_url: ""
canonical_url: "https://divinelovesanctuary.com/nurturing-the-mind-or-the-soul-its-a-choice/"
notes: "Two corrections from source text: typo 'Iit' corrected to 'It'; paragraph break added after 'to bring true healing to you' for readability."
significance: ["Key Teaching"]
language: en
excerpt: "A yearning soul is the key that will unlock the door to God — and a curious mind is but a symptom of the yearning soul."
series: []
last_edited: 2026-04-17
---

Your teacher Augustine is with you.

A yearning soul is the key that will unlock the door to God, and a curious mind is but a symptom of the yearning soul. For the mind must feel comforted by this intense desire that does not originate from mind but from the soul. Those who seek for truth, seek because their souls long for truth, and those who seek for truth through many teachings seek in a direction that often thwarts the yearning soul, for the mind misunderstands the yearning. The mind seeks dominance. The mind wants control. And the soul, the eternal part of your being, is patient and waits for that time when there is an opening, a crack in the armor where the fears fall away and you are willing to feel the vulnerability that comes with those raw yearnings, often tinged with pain and heartache, that come forth to God seeking solace, seeking His loving Touch, to bring true healing to you.

My beloveds, it is the yearning soul seeking to not be alone, seeking to know joy, fulfillment, seeking God and in this seeking, this longing, this wordless prayer to your Heavenly Father comes His Holy Spirit to Touch your soul, to convey His Love which shall reside within for all eternity, this great gift of Love.

So you see, you can ask many questions, appease the mind in its discomfort, but the mind is not in a place of control when these deeper awarenesses and experiences come into your being and consciousness. The mind seeks to rationalize, to find structure, to understand with faculties that are in essence incapable of understanding these truths, for these truths originate on a higher level of understanding, of knowing, and only the soul infused with Divine Essence, opened and developed by this Love so that the faculties of the soul are opened and the capacities of understanding come with these perceptions of the soul. This is where faith begins, my beloveds, to have faith and trust that through this experience of being touched within your soul will come, in time, and flow in harmony when you are capable of understanding through the mind of the soul, the perceptions of the soul.

In your world the mind is revered, the mind is empowered and nurtured, the mind is considered by most to be the only faculty of the individual able to reason and perceive truth and this, my friends, is error. For the soul has greater faculties, deeper perceptions and a greater capacity to understand the universal truths of the Creator. And so, for those willing to step forth into the realms of their soul, knowing full well that what lay within that deep cavity that is your true being is much heartache, many places and corners harboring deep pain; that in order to step into this chamber you must be strong and of strong faith to allow God to come with you, to say to your Heavenly Father, "Hold my hand through this journey and infuse me with Your Love so that I might with strength and clarity release these things within and allow You and me together to live in this place of communion and Light, this deep place that I will carry with me for all eternity, becoming ever brighter and more beautiful. Allowing all that is not in harmony with your Love to fall away from me and all truth, all goodness, all joy and deep peace to replace these things that I hold so dear to myself and are not of God or love or true joy. And I will release these things and allow the benediction of Your Holy Essence to heal everything within me, to open my arms, to bring me to at-onement with You."

Yes, my children, this is a great journey, one which you must be willing to take, one which God in His wisdom has given you the choice to take. Many defend and rationalize their reluctance, for within them they know intuitively that this journey has its difficulties, for to confront your true selves, to be in that place of vulnerability is not easy. To seek true, deep and permanent healing, you must be strong in faith, for it is with faith that you are strengthened; it is with faith that you understand and are open to this experience. Words will not bring you to that place of understanding but will merely justify your reluctance. A deep longing, even if that includes overwhelming sorrow, will bring you to God, a deep longing to say "I am merely your child in this universe of your creation" will bring you to a place of innocence and longing and openness. But to say "I am all powerful, I am in no need of something more than myself" will set you upon a different road, a longer road, though this too shall bring you to God, but to God in a different way, an understanding that is of the mind and the soul though in time will be cleansed in this way. It will never truly know this great Touch that ignites a different capacity of knowing and being, which in turn will bring one into the Celestial Heavens and upon a journey that shall last for all eternity in this great, joyful unfolding and expanding of your being and your pursuit of the at-onement with God.

Yes, each soul has a choice and many upon this Earth plane are not aware of these choices. Many seek. Many find such a multitude of explanations for life but rarely go beyond these mental understandings to something that originates from the soul. And you have come, my beloved, beautiful souls, to learn of this new way, the way of the birthing of the soul, the igniting of these great potentials through Love. This is a gift to you and a choice, for there are many roads to walk, many ideas to pursue, many to talk to who will give you their perceptions of truth, but in the end it must be your perception of truth, your road to walk and God will lay a road for you, unique to you, if you allow God to do so. You must, however, recognize within yourself the longings of your soul and allow the strength of your faith to bring those longings forth to God and to trust in this journey, this path that God has laid before you.

It was ever thus. It will ever be thus, for each soul has the gift of free will and each soul has a choice of where they must walk, to whom they must serve. For do they serve their minds or do they serve their souls? Do they serve God or do they serve the great power that humanity has accumulated over so many, many years that does not serve God but serves to aggrandize humanity?

Yes, these times of choice are crucial, they are crucial for they are to inform so much of what is to come in your life, and many blessings await those willing to be with God, to serve God, to love God, many blessings, many gifts, many opportunities to serve God, much Light and a great unburdening of the soul. And for those who desire to feed their minds and avoid plummeting their souls, what awaits them will be more questions to be answered, more conversations leading to where? more concepts, more of the mental imagination than the truth, with each reinforcing the other in these mental understandings. This so often leads one down a road that has no path of truth, but a dead end. And so humanity, for the most part, continues upon these roads of enquiry, some leading to a measure of truth and some not, some having a measure of truth but not entirely, some completely in error.

The many religions and understandings of your world are based upon this compulsion of the mind to explain reality, for the mind truly does not have this capacity, for it is the soul that truly knows. Each being in this world has a soul and therefore has the capacity to know truth. But for most in this world the soul is neglected, misunderstood and little attention is paid to these yearnings to be with God. The mind remains firmly in control, the mind becomes the dictator that would be, and in this so much in error can be rationalized, love is thwarted by the intellect, a great thirst for power, personal power, power over others, desire for accumulation and materialism. Much fear comes as the mind cannot truly grasp all the possibilities of this world, and there is no room for faith and a trust in God to guide and protect. This is so with each of you to some degree, my students, you wrestle with these dilemmas each day and truly you cannot deny your minds for it is a part of you and a gift from God, but to have your mind in balance and working in harmony with your soul, and in time the mind of your soul, enveloping and infusing your material mind. In this way you will find answers, many answers that are not mere speculation but are true and this takes time and a great deal of effort on your part, in prayer and in receiving the great gift of God's Love which makes all of this possible. It is the great key, the great gift, the highest of all gifts, the highest of all blessings this gift of God's Love.

And though your minds may remain sceptical, each soul will recognize the truth of this given half a chance, and if you do indeed take this truth to heart all that I have said will be demonstrated and become viable. But you must make this effort and choice.

So, my beloved students, I have talked seriously about the choices that you and all of mankind have in their existence in this world and in the existence in the world to come in spirit, a great choice and each journey has its rewards, potentials. Only one of these paths will lead to at-onement with God, the other is at-onement with mankind and a pure and perfect world. So I bless you, my students, and I wish you God's speed upon your journeys and I pray that you will use wisdom and plummet your souls to discover what it is that you truly wish for in your spiritual life, for when you follow the wishes of your soul you are true to yourself, you are true to who you truly are, that great gift that God created in the world, which is you, my beloveds, you, unique and beautiful, full of so much potential and capacities.

Continue, continue, and we will be with you to help you in your choices, to educate you upon your journey, to sooth your minds and stimulate your souls. God bless you, beloveds. May God's Love find a constant inflowing into your soul. Beloved children of God, Augustine loves you, loves you dearly. God bless you.