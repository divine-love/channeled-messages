---
message_id: 2016-12-06-af-seretta-kem
title: "Talk on Mediumship: The Laws of Communication and Rapport"
date: 2016-12-06
spirit_id: seretta-kem
spirit_name: "Seretta Kem"
medium: Al Fike
location:
  city: Hawaii
  region: HI
  country: United States of America
gathering:
message_type: ["Teaching"]
description: "Seretta Kem delivers a comprehensive teaching on the gift of mediumship — how spirit communication works, the conditions required for it, the dangers of expectation and premature gift-opening, and the crucial discernment principle that any message not centred on God's Love and the flowering of the soul is not from a Celestial angel. He concludes that while mediumship is a blessing, the gift of Divine Love received in prayer is infinitely greater."
primary_subjects: "Mediumship & Developing as an Instrument"
secondary_subjects:
  - "Circle of Light & Prayer Circles"
  - "Discernment & Truth-Seeking"
  - "Receiving the Divine Love through Prayer"
  - "Unique Soul Gifts"
people: []
spirits: []
keywords: ["mediumship", "spirit communication", "rapport", "laws of communication", "conditions", "discernment", "trance", "direct voice", "expectation", "gifts", "Divine Path", "Natural Path", "Celestial angels", "soul gifts", "circle of light"]
questions:
  - "How does spirit communication through a medium actually work?"
  - "What conditions are needed for angels to communicate?"
  - "How do I know if a channeled message is truly from a Celestial angel?"
  - "What is the warning sign that a message is not from an angel of Divine Love?"
  - "Is mediumship the most important gift in a Circle of Light?"
  - "How do I develop my mediumistic gifts without forcing them open prematurely?"
  - "What is the difference between trance mediumship and conscious mediumship?"
  - "Why should we not have expectations of receiving a message in prayer circles?"
  - "How do I discern between teachings of the Natural Path and the Divine Path?"
  - "Can every soul develop some form of mediumship?"
  - "What happens spiritually in a Circle of Light beyond what we can see?"
  - "How do I know if my desire for spiritual gifts is coming from ego or genuine service?"
  - "What is more important — receiving a message from a spirit or receiving God's Love?"
related_messages:
  - 2016-04-13-af-seretta-kem
  - 2015-11-28-af-seretta-kem
  - 2015-08-20-af-james-padgett
audio_url: ""
canonical_url: "https://divinelovesanctuary.com/talk-mediumship-laws-communication-rapport/"
notes: "Two minor transcription artifacts corrected: space before comma in 'When this is so , many things' and missing space in 'acknowledgement of God.It is useful.'"
significance: ["Key Teaching"]
language: en
excerpt: "If within a message there is no mention of God's Love, that it is not about the opening and flowering of the soul — it is not from an angel. You must discern for yourself through your own soul's acknowledgement what comes through as true."
series: []
last_edited: 2026-04-17
---

Greetings to you, my fellow travellers upon the Divine Path. I am Seretta Kem and I wish today to talk on the subject of mediumships since many of you are interested in this particular subject and it is a blessing indeed to be able to communicate to you in words through a medium in this circle.

Firstly, I wish to emphasize that when you are a part of a circle of prayer your prime objective is to seek the Divine Love within your souls, to pray to be used as channels of Love and healing and blessings for others, to bring the presence of God in your midst, to have a deep communion between yourselves and your Heavenly Father.

Now, because you have formed a circle and your desires are for communication with the angels and they harmonize with your desires for connections with God, you are able to benefit from the blessing of a message from an angel – perhaps a teaching, or words of encouragement and love. And we who are with you and support you are happy to communicate through an appropriate medium.

Spiritual conditions must be built within your circles, for when you reach for the highest it is indeed an effort of reaching, of pulling in those conditions harmonious with Divine Love, harmonious with the teachings of Divine Love, harmonious with the angels of Divine Love. So the Laws of Communication and Rapport come into effect, firstly from your desires, your prayers, the harmonious condition which you have build amongst yourselves. Often those who belong to a circle of prayer where there are mediums present are very desirous of a message, they have expectations of such. This, my brethren, is not an attitude that you must cultivate amongst yourselves for the blessing of Divine Love has far greater importance within a circle than words of encouragement from an angel. Yet, when conditions are right, we do indeed step forward and we are happy to do so, but we do not want to distract you from this primary effort in prayer and communication with God.

So much more happens within a Circle of Light than many of you are aware of. Some get glimpses, some see visions, some see the Light that is generated in a Circle of Light and how it is dispersed to many souls. For you are generating a great deal through your prayers, your efforts together, and it is of a great deal of importance that you recognize that you are responsible for the conditions that you bring within the circle, the thoughts, the desires of your soul. It is very important that you make efforts each day to be with God in prayer and to receive His Divine Love. With each day that passes a concerted effort, my beloveds, is important. In doing this you create within yourself a Light, a light within your soul, as you well know, and when you bring your Lights together in a circle such as this, you create the conditions that are favorable for the angels to draw close and for God to be in your presence. In these conditions it is easy for us to communicate.

Now, for those who are often present in circles where communication does take place there is a tendency of expectation, even a casual air of expectation and acceptance. One might even say that it is taken for granted that messages are given and that there is a perception that this is an easy task. It is not an easy task, my friends, for the angels to come and speak in this way and come and make rapport with each one of you. This is unusual on the Earth plane; we do not move about the Earth easily for these conditions are not in harmony with the soul condition of an angel. So these are exceptional circumstances and we understand for those who do not participate in these circles often, to receive a message is something to be prized and appreciated.

Conditions must be built by us for this take place and you have experienced the differences in particular locations when you sit in circle in this way. It is important to have a condition that is harmonious, to be in a place where Light is easily generated and for all concerned to be comfortable and in a prayerful stance and it is important that you all focus as one voice in your prayers and your efforts to reach the highest.

There are many mechanics involved from our side of life that I will not go into because they are complex and it would be difficult to deliver these complexities through this instrument and it would take a great deal of time to do so. Suffice to say that it keeps us very busy to help to create, to assist in building the conditions in this room and amongst you. It is also helpful that you are in a prayerful and meditative stance, a quietness, a receptivity, a sense of togetherness, fellowship, and love.

Indeed, your sense of responsibility in this regard comes somewhat naturally for those who have practiced this routine. It is not difficult to pray, to be quiet, to be open and to listen but at times it can be challenging for the medium to continue an extended time of rapport and communication when there are distractions about, noises and lights.

For the medium must allow a certain channel and component of their material minds to be opened and allow the words to flow without interruption and without their particular thoughts coming in so as to affect what is spoken with the message. A medium who is able to focus in this way and to step beyond their own mental condition is a good medium and some go very deep into trance, while others are aware of what is being spoken. It varies from one to another, and we work with many mediums and on many different levels. Each soul has some mediumistic qualities and can be used in many different ways from healing, by giving impressions, to bringing voices though, even direct voice.

Yes, there are many aspects to mediumship as there are with many things to do with the spirit and the soul and I know you all find this very interesting. You all are eager to have experiences which bring inspiration and truth forwards into your consciousness. But I would not recommend that you push the issue in as much as your will intervenes to a point that certain gifts are opened prematurely. For gifts open and flower with God's blessings in a fluid and harmonious way. And in many respects the gifts that are opened within you are often ignored because you are firmly planted within your minds, your material minds, and you do not recognize what is happening on a deeper level. This recognition can only come when you have attuned yourself to your souls; when you are aware of what is percolating within yourself and what can manifest through you, your beautiful souls.

It takes time. It takes a grounding in the truth. It takes a desire for the highest and a discipline to walk this Divine Path. For many things can be manifest with spirits who are operating through you who are not of the Celestial. Yes, each one of you could easily open to this and bring forth many manifestations but what is the value of that, my beloveds? What do you gain by this?

All that manifests on this Divine Path is for the joyful acknowledgement of God. It is useful for the progression of your souls, it is done in God's wisdom and guidance. This is what you must aim for always when you walk the Divine Path and nothing less than this, my beloveds. For if you walk a lower road you will find you are distracted, diverted, enmeshed and entangled in conditions that are not altogether for your benefit and when you work with God, all is for your benefit, my beloveds, all enhances your life and also enhances many other lives as you utilize your gifts and God utilizes your gifts for the service of mankind.

And each day you are confronted with the choice of reaching for the highest, of acknowledging that which is of God is what is important and you must ask yourself that question. What are my motives? What do I desire and why do I desire this? Am I desiring this because I want to serve God more fully? Am I allowing God to work through me in ways that he deems, through His wisdom, to be effective in a beautiful outpouring of love or am I seeking for my own personal comforts or to bring something to myself which will make me feel good and important?

These are the traps within the human condition. This is how many are confused and do not understand the purpose and the power of the spiritual gifts of the soul. They are for the good of mankind, yet often they are unrecognized by many and this is not important. It is important to manifest the Light and Love that is within your soul in ways guided by God, and all else is often irrelevant for when you are truly in alignment with God and you walk with Him in this harmonious way, your fulfillment comes with this relationship of love, from that deep communion between your soul and God's soul. When this is so, many things will manifest through you and they will feel natural and good. You will prosper in joy. You will benefit in many blessings, and you will not see the recognition of others as something wholly important, no, the recognition that comes from God will be your fervent desire. You will place your focus upon the Heavenly Father.

It is better to be in prayer and know and feel His Love than to see us spirits or have us communicate through you, or to manifest other things. For if this is done without love it is hollow, it is a distraction.

So, my beloveds, is the gift of mediumship a crucial gift? No. It is a blessing; it is a benefit that comes as your souls grow in the Love, but without it, is there something you are missing in a prayer? No, if you have received God's Love, the greatest gift of all and this comes wordless, in a deep flow of connection and recognition and you seek this above all else, there is nothing greater than this gift, my beloveds, and this is your focus, this is your time with God. Yes, we will take advantage of times together such as these to speak to you as a gift of love and it is our hope that you will listen to these words, possibly listen more than once and contemplate what we have to say because our desire is to educate and to facilitate your growth in whatever way, whatever channel and instrument and gift that can be used to encourage and to educate, to open you to higher levels of understanding.

But I will warn you, if within a message there is no mention of God's Love, that it is not about the opening and flowering of the soul, it is not from an angel and you must discern for yourself through your own soul's acknowledgement to the spirit of truth what comes through as true and relevant to the development of your souls.

There are many messages in the world and philosophies, understandings that contain truth, of course. I do not mean to say that they are irrelevant, but you must, if you are committed to the Divine Path, be able to discern between the teachings of the Natural Path and those of the Divine Path, if you are to remain consistently upon this path. I do not suggest that you reject all else but that which is of the angel's teachings but to have a discernment and not to be overly distracted by these teachings is beneficial to you. For, remember it is your souls you are developing not your minds and most teachings upon the natural path are based upon the development of the mental faculties, the purification of the soul but not the expansion of the soul in the Divine Love.

So when you encounter a circle and there are messages therein, listen carefully, use your ability to discern. Be strong and of good faith and you will know, you will know.

So, I have spoken a great deal, my beloveds, and I hope I have brought clearly through some understandings about the gift of mediumship and the gift of communication and rapport with the angels. It is not something to be taken lightly and it is a gift for you on Earth to have such things but the greatest gift is the gift of Divine Love which you must focus upon above all else. In time, those who are somewhat confused, the confusion will subside and you will know in a clear way what it is that you truly desire within your souls and this will bring you joy. You will not want so much for knowledge, instead you will not want for Love, and you will feel a deep and abiding joy and peace.

I thank you, my beloveds, I am Seretta Kem, I thank you for listening and I bid you blessings of love. I am your humble servant, I am with you often and I am happy to speak. God bless you. God bless you.