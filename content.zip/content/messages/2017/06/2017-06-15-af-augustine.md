---
message_id: 2017-06-15-af-augustine
title: "Lesson on Judgement"
date: 2017-06-15
spirit_id: augustine
spirit_name: Augustine
medium: Al Fike
location:
  city: Gibsons
  region: BC
  country: Canada
gathering:
message_type: ["Teaching"]
description: "Augustine delivers a comprehensive lesson on the urge to judge, teaching that our reactions to others' conditions reveal our own soul state, that judgment is incompatible with Love, and that the antidote is not suppression but conscious choice - catching yourself in the act of judgment and choosing Love instead. He includes an extended first-person inner monologue as a template for how to make that choice in the moment."
primary_subjects: "Self-Love & Acceptance"
secondary_subjects:
  - "Humility"
  - "Cleansing & Expiation"
  - "Walking the Divine Path"
  - "Spiritual Discipline & Daily Living"
people: []
spirits: []
keywords: ["judgement", "judgment", "self-judgment", "acceptance", "compassion", "perception", "anger", "resentment", "superiority", "Divine Love", "inner monologue", "choice", "Light", "soul condition", "vulnerability"]
questions:
  - "Why do I judge other people even when I don't want to?"
  - "Why does it bother me so much when others judge me?"
  - "How do I stop being so hard on myself?"
  - "Is it possible to perceive someone's faults without judging them?"
  - "How do I respond when someone is judging me unfairly?"
  - "Can I really choose not to judge or is it just a reflex?"
  - "Why do the things that bother me most about others often reflect something in myself?"
  - "How does judgment affect my own spiritual progress?"
  - "What is the difference between judging someone and perceiving their condition?"
  - "How do I break the cycle of self-condemnation?"
  - "Why does judging others feel satisfying in the moment but harmful afterward?"
  - "Am I a failure if I keep slipping back into old patterns of judgment?"
  - "How does loving someone neutralize the urge to judge them?"
related_messages:
  - 2016-03-30-af-augustine
  - 2017-01-16-af-keea-atta-kem
  - 2015-12-14-af-augustine
audio_url: ""
canonical_url: "https://divinelovesanctuary.com/lesson-on-judgement/"
notes: "Message given at the group's request on the subject of judgment. The extended first-person inner monologue in the fourth main paragraph is a practical template for choosing Love over judgment in the moment."
significance: ["Key Teaching"]
language: en
excerpt: "With Love, I cannot judge. With joy, I cannot judge. With acceptance, I cannot judge. I may embrace all goodness and Love, and this I will do as I walk upon this Divine Path."
series: []
last_edited: 2026-04-23
---

You have requested a talk on judgment. So I will talk about the urge to judge your brothers and sisters in this world.

This does not reflect well upon your soul progression. The desire to judge, those feelings that you are uncomfortable with, how another is in the world, express to you things that reflect back to you your own soul condition and personality. They cause aggravation because you see something within yourself that is similar and it is difficult and challenging to recognize your own humanness and how the great body of conditions within this world reflect upon your own vulnerabilities. In this you more readily judge yourself than anyone else.

Now one may observe and perceive a condition that is not in harmony with God's Love; one may do so within themselves or within another. It is your reaction to that perception which is a good indicator of your own soul progression. Are you angry or perturbed? Do you feel self-satisfied when you see a flaw in another? Do you wish to be superior to another? These human tendencies are exactly those conditions which we are imploring you to release, to change those patterns of thoughts and inclinations, to not feel anger, resentment, to not judge, but to love.

If you can indeed perceive and see the root of the condition, especially within yourself, then you are making progress towards making change and healing within. What inhibits that progress are the negative emotions which accompany this perception, your judgements. It does take a great deal of discipline and practice to not indulge yourself negatively.

When you are in a state of loving, embracing and accepting others, then can you judge? Are you capable of judging? No, my beloveds, your feelings are acceptance, forgiveness, compassion, recognizing that those negative conditions are alive and well within your world and it is these very conditions which cause a great deal of suffering amongst mankind. You have prayed to be lifted out of the human condition, to be in that state of loving acceptance within the flow of God's Love. With soul wisdom you do indeed perceive the conditions of humanity and those conditions within yourself. This is inevitable because all those things that are not in harmony with God's Love must be released from you in time upon your journey to at-onement with God.

Do you not have enough upon your plate regarding these issues and conditions within yourself which need to be healed and released? Do you need to include those conditions of others, to carry them within your consciousness in a way that only judgement brings, an attachment, an expectation, a desire for the other to change? Yes, others may indeed be judging you and laying these expectations upon you for change. This is indicative of their own inner condition, their own sense of inadequacy, their own desire to change. When someone is judging you, my beloveds, say a prayer for them. Do not allow these conditions to infect your own mind, for you are then doubly burdened by your own expectations and the expectations of others. You do not need this condition to be active within your consciousness. When you send love how can judgement survive the infusion of love? Each time you do this for yourself or for another, you make progress within your soul, you increase your own Light. Yes, you may perceive a condition within yourself or another, but how and where you go from there is your choice.

The human way is to allow judgement to enter into the interaction but the way of Divine Love is to neutralize negativity with Love. To say to yourself and catch yourself when you begin to judge, to say 'no I will not judge this person or I will not judge myself and condemn myself to continue the cycle of negativity and darkness. I will choose to Love. I will choose Light. I will let go of my need and my habit to judge. I will perceive. I will recognize and upon this, I will change and I will bring more Light and acceptance and beauty within myself. I will put my energy towards change rather than judgement. I will put my thoughts in this way of loving. I will have the compassion within myself that recognizes that I am not perfect. I am not yet redeemed by the Father's Love, yet I know as I progress upon this Path and change those conditions that are in the way of such progression, that I will find my at-onement with God, that true soul desire within me. Joy will come into me in great abundance and with joy I cannot judge. With Love, I cannot judge. With acceptance, I cannot judge. I may embrace all goodness and Love and this I will do as I walk upon this Divine Path, this Path that sets Love above all else. To be a channel of Love, to place my faith in the power of Love, to know that God's Love is the greatest Gift and Light within me. Then when I am faced with the dilemmas of judgement, I will choose Love.' With that choice, beloveds, you will have made a statement in the world and within your own inner world, that Love is indeed the most precious and powerful element in your life.

It is easy to fall into judgment; it is the way of this world. Unfortunately, these conditions are empowered by such thoughts and emotions, conditions of darkness. Have you not decided and committed yourself to bring Light to this world? If this is the case then bring Light to yourselves. Make your world a place of Light and harmony. Work towards this end and even when you fall into judgement, do not condemn yourself, piling on more negativity, but to catch yourself, be aware of how easily you slip into this condition and decide that you will no longer do so. Be a child of the Truth and a child of God rather than a child of the condition of man.

This choice is before you with each breath and for those with awakened souls the act of judgement, of not expressing Love, causes you pain. Your souls feel the condition that you create and it is hurtful. So, you are in the process of awakening, you grow more sensitive with each day and in order to make life easier, I would suggest that you live the Laws of Love as best you can and when there is a need for correction, have faith that you have the strength and the ability to do so, for you truly do. There is no need to say, "I am a failure. I am unworthy." These things are irrelevant in the World of God for no soul is a failure and no soul is unworthy. Every soul is precious. Every soul is loved by God. Every soul has great potential and continues to grow in their own ways upon their own path towards Light.

You my beloveds, have taken great strides. You are no longer children and as such there is a need to be responsible for your actions in many different ways and to embrace that responsibility with joy, not fear, and with anticipation that you will succeed. You are succeeding in this, in the transformation of your being as you release the conditions of humanity and embrace the Beauty of God. We understand it is not easy to change in this way, to swim against the current of the present conditions of this world, but as you continue to swim, you are strengthened by God. As you continue to pray for the support and Love that you require to make this journey, do not the blessings intensify and give to you what you require to make this journey of Love? For a soul that truly loves itself and is embedded within this pure Love of God there can be no judgment, only acceptance and perception.

So, you feel our Love. Do you feel judged? Are you judged? No, my beloveds. You are given guidance and support, encouragement and wisdom. We understand your struggles more than you understand yourself. We know that each one of you and all of you who struggle for Light in this world are putting forth a tremendous effort to be in the Light, to be that beautiful soul that God created you to be. Do you see how much joy this gives us? Like a parent seeing a child thrive and develop into that beautiful being that is meant to be. How we indeed love you so dearly and want and pray for the best of all possible outcomes in your lives. We do everything we can to help support you upon this journey. It is our joy to do this, our deep desire to see you thrive, to be unburdened by these conditions that are not in harmony with Love, to walk upright in Light, to be a channel of Love, to be swept along in that great river of God's Love.

So, you see, we do not judge, we do not feel impatient, we are not angry, we do not have unreasonable expectations. We merely love and have faith that God will carry us all upon this journey towards Light. The fact that we may accompany you upon this journey is a great blessing for us as well as you. Be joyful in this, my beloveds. Acknowledge how beautifully God has cared for you, how wondrous is this journey, how perfect is your life and yourself in as much as you have these great potentials and opportunities to grow in Light and to be in Light and emerge as a powerful channel of God's Love with many gifts and beautiful offerings of Love to your brothers and sisters. You are carried. You are protected in Love. There is no need for fear or judgement, to bring yourself unneeded pain and negative conditions that are irrelevant to your present condition and journey. Be with God. Seek His Succour. Know that you are and always will be His Child.

God bless you, beloveds. I am Augustine and again I thank you for the opportunity to bring a lesson forward. Continue to discuss the challenges of your life and the glories of your life and we will attempt to educate and contribute to your growth and enlightenment. God bless you. God bless you, beloveds. I love you.