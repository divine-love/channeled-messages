---
message_id: 2017-09-13-af-keea-atta-kem
title: "Make Love Your Guiding Truth Through Earth Changes"
date: 2017-09-13
spirit_id: keea-atta-kem
spirit_name: "Keea atta Kem"
medium: Al Fike
location:
  city: Gibsons
  region: BC
  country: Canada
gathering:
message_type: ["Teaching"]
description: "Keea atta Kem delivers a wide-ranging prophetic teaching on the intensifying changes coming to the world - magnetic pole shifts, disrupted animal behaviour, dramatic environmental and social upheaval - teaching that these are the consequences of humanity's disregard for God's Laws of Creation, and that those who carry Divine Love will be guided to scientists, leaders, and seekers as rocks of stability and truth in the coming storms."
primary_subjects: "Earth Changes & Prophecy"
secondary_subjects:
  - "Collective Awakening & Redemption"
  - "Preparation for Earth Mission"
  - "Celestial Governance & Spiritual Law"
  - "Lattice of Light & Global Prayer Network"
people: []
spirits: []
keywords: ["earth changes", "magnetic poles", "pole shift", "animal behaviour", "climate", "consequences", "free will", "harmony", "custodians", "scientists", "leaders", "closed system", "chaos", "sanctuary", "restoration"]
questions:
  - "Is the Earth really going through major changes right now?"
  - "Why are animals behaving so strangely lately?"
  - "Are the changes happening in the world a punishment from God?"
  - "What is causing so much chaos and disruption in the world today?"
  - "How do I stay spiritually grounded when everything around me feels unstable?"
  - "Does God have a plan to heal the Earth and humanity?"
  - "What is humanity's responsibility toward the planet?"
  - "How do spiritual people fit into the global response to climate change and world crisis?"
  - "Will there be safe places during the coming world changes?"
  - "How does ignoring God's Laws of Creation lead to consequences?"
  - "What does it mean that the Earth is a closed system?"
  - "How can love be a practical response to a world in crisis?"
  - "Why are magnetic pole shifts happening and what do they mean?"
  - "Can prayer really make a difference to what is happening in the world?"
related_messages:
  - 2017-09-12-af-confucius
  - 2017-09-12-af-augustine
  - 2017-09-12-af-martin-luther
  - 2016-12-07-af-andrew
  - 2015-12-21-af-peter
  - 2016-03-21-af-augustine
audio_url: ""
canonical_url: "https://divinelovesanctuary.com/make-love-guiding-truth-earth-changes/"
notes: "Fourth message from the September 12-13, 2017 Gibsons gathering, following three messages from September 12. Keea atta Kem mentions that Al Fike has seen some things that are coming in vision."
significance: ["Key Teaching", "Prophetic"]
language: en
excerpt: "You will be a rock in a world disrupted by conditions of change - and despite all the chaos around you, you will feel the strength and peace and wisdom that comes with your soul enlivened by Love."
series: []
last_edited: 2026-04-23
---

I am Keea Atta Kem. I have come to speak to you of the changes in this world, the changes that have already happened and the changes that are going to happen. At present those changes within the world are not particularly noticed except when they bring some heartache to those people who are directly affected as the weather changes.

But each of you recognize that the atmosphere of this world is changing. Something is happening that is different. It is not that long ago that you felt the continuity to your life. You had certain expectations regarding the conditions of your life and what you may come across in the future. Now, is it not true that you do not feel that continuity, that expectation, that all is different, that times are different, that what may be in this world is not so certain? You have turned more to prayer to be with God and to find the certainty in your relationship with your Creator. This is what you must do, beloved souls, to be in prayer each and every day, to allow God to guide you each and every day, and to put aside those thoughts and expectations that seem to inform your life. For as you are able to step aside from these expectations, to allow God to guide and inform your day, there will indeed be surprises, unexpected opportunities, times that you may even feel confused as to what is happening around you. But this is God orchestrating your life, preparing you for what is to come, helping you to put yourself in order so that you may have the strength and the perception and the faith that will carry you through and make you a channel of Love, that you may reveal the Truth to others and may reassure many as they feel their confusion and lack of understanding.

Humanity goes blithely along in their life with the thought that all will be as it should be. Yet, these are not the conditions that are inherent in this world at this time. There are many changes in the works. Even the very energy of this earth is changing, the magnetic polarities are shifting, the energetic compass of this earth is shifting. So, not only humanity but all of the creatures of this earth are feeling a shift, a change and a confusion. You are beginning to see in this part of the world many more animals encroaching upon your homes. And this is not because they are emboldened. No, my beloveds, it is because they are confused and they do not have that sense of what is harmony with their existence. This too will intensify. It saddens us to see the fear that this creates and how these creatures are killed, put aside, because there is not an understanding of what is happening in this world.

So it will go in the next several years, an intensifying of these conditions. This instrument has seen some things that are coming. We will attempt to inform those who can see, are open to this guidance so they may prepare for what is to come. I wish I could say to you, my beloveds, that this will not be traumatic in your lives but unfortunately, because of the conditions that have been forged by the behaviour of mankind, there is and will be an equal response from the natural order of things in this world. This will bring dramatic change and suffering to humanity. Those who are able to receive the guidance from God and who desire the protection from God, an envelopment of God's Hand upon them, will be able to navigate through these tumultuous conditions and find sanctuary and find opportunities to comfort and to teach others. For in these times of changes comes opportunities as the souls seek answers to these dilemmas. God will place you in the right situations so that you may teach and give clarity and Love and you may speak of God's plans for humanity, to bring humanity back to balance and harmony.

For this is the prime operation of the universe, to seek harmony. So this must be enacted in this world even though humanity has free will and has been allowed to do as they will. There are always consequences, my beloveds. If you do not accept the reality of the universe and how things are ordered and how the energies and manifestations of God's Creation come together in harmony, when this is ignored, there are severe consequences, not because God wishes to punish humanity. No, this is not the case. But when humanity ignores the Laws of Creation, there is a response. For every act, there is a reaction. For every choice, there is a response. Humanity often does not take the road of learning Truth through contemplation, through listening to the wisdom of their souls. No, humanity often presses forward testing the limit of their world and their abilities. This is often reckless and unloving. So the consequences come as this ignorance and error doubles and redoubles in this world, bringing more intense response, more difficult situations and conditions. Yet, God sends His angels, many spirits of Light, those of you who wish to be in harmony with God's Creation, all of you, all of these forces of Light and harmony are coming together to salvage and reclaim humanity.

So many do not see the darkness that prevails in this world. They ride upon the surface of their consciousness, seeking the fulfillment of their material desires and mental machinations and serve to hide away from Truth and harmony. So it is for you, my beloveds, to speak the Truth, to awaken those who can and will see clearly so that in time humanity will come to a balance once more. This does not mean that their free will be suspended. No, my beloveds, but it means that they will use their gifts and capacities with greater wisdom and understanding. For the harshness of the response that is coming will jolt mankind into an awakening that they cannot continue to seize power, to desire control, to negate Love in this world. They will see that if they are to find a harmonious life, they must serve one another in Love, they must see this beautiful planet as a whole organism that needs to be respected and that all of humanity are custodians of this beautiful planet and must tread with sensitivity and wisdom.

You cannot expect to have all your needs fulfilled and more and more and more, taking from this world and never thinking of what must be returned and given back in Love. For it is a closed system. Your scientists understand this fact. It cannot be put under stress ad infinitum without some response and reaction in the physical laws of this world and the nature of this beautiful created planet. So, all of humanity, those in the scientific community, those who are spiritually inclined, those who pray to be close to God, those who are leaders in the world, those who are seeking solutions - all must come together and acknowledge that despite the great gifts of humanity, they are unable to see the solutions clearly. That it requires not only these gifts, but a humility and a desire to seek the wisdom that God has to give and to seek to Love, the power of Love, the powerful healing that Love brings and the awakening and wisdom that comes with this Love, God's Divine Love.

So you have a very powerful message to give, my beloveds, a message that is key and vital to the survival of humanity. You must always keep this message forefront within your consciousness and the motivations that you have in your life, that it is Love that is the most important Truth. It is Love that you must live by and enact in your life to become that example for others. In time God will guide you to many, many different souls, scientists and leaders, religious leaders, political leaders, those who have influence in this world. You will be guided to these individuals and as your gifts increase, and abilities, as the Love grows within your soul, this will bring credibility. These individuals will sit up and take notice of you because you have something very unique and special to give. Within your soul is a deep desire to fulfill this purpose, to bring these Truths to help humanity through this trying time.

So you continue to grow and develop, to make efforts to increase your gifts and increase your Love. This we continue to support and be with you upon this journey of soul awakening, receiving the Father's Love in ever greater abundance, of opening your eyes to the truth of this world and the Truth of God's Creation, of knowing God intimately. There is no doubt, there is no worry. Each day then becomes a gift, each day will bring greater wisdom and Love, understanding. The joy will increase within your heart. Despite all the chaos around you, you will feel the strength and peace and wisdom that comes with your soul enlivened by Love. You will be a rock in a world disrupted by conditions of change, conditions that are meant to bring back harmony and balance to this world.

So, my beloveds, you have a great responsibility. If you are nervous of this, concerned of what God asks of you, know that God's Plan is perfect, that He has created such beautiful souls with many gifts and talents and that He is ready to launch His channels of Love in this world to bring what is required. For God wishes that all humanity come to a deeper understanding of the meaning of their lives. So as you move forward the trepidation will leave you, and you will be strong and clear. You will have the strength of your faith, the clarity of your soul's wisdom, the knowledge that God has His Hand upon you and there will be no doubt, no fear, no worry, only joy and a deep desire to bring Truth to this world that God may heal this world and heal all upon this world. For this is the enactment of His Love, this wondrous, merciful Love for each and every soul, each and every part of this world. His Desire is to bring harmony. As you listen to His Will, you will understand, you will see. You will feel confident as you move forward despite all that is around you that seems topsy turvy and confusing. You will see what is coming, which is the restoration of Light in this world.

God bless you, beloved souls. I am Keea Atta Kem. I love you. I am with you as you continue to grow and question and pray and delve into these wondrous Truths of God. What joy it brings us in the Celestial Kingdom to see you grow as the Light beams within you and the Love continues to flow. You are being healed and restored, given what you require to be God's channels with great purpose and gifts and Love. I am with you and my love is with you. God bless you beloveds. I am Keea and I love you.