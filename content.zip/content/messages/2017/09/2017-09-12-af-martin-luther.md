---
message_id: 2017-09-12-af-martin-luther
title: "Understanding the Laws of Love and the Regeneration of Our Souls"
date: 2017-09-12
spirit_id: martin-luther
spirit_name: "Martin Luther"
medium: Al Fike
location:
  city: Gibsons
  region: BC
  country: Canada
gathering:
message_type: ["Teaching"]
description: "Martin Luther responds to the group's conversation about limitations, teaching that God has created an ordered universe governed by laws, that the Law of Divine Love supersedes all others and can bypass the long process of natural love purification, and that each soul bears personal responsibility for their own regeneration - for God cannot spoon-feed a soul into harmony without that soul's own desire, effort, and prayer."
primary_subjects: "Celestial Governance & Spiritual Law"
secondary_subjects:
  - "Rebirth of the Soul (New Birth)"
  - "Free Will & Human Error"
  - "Soul Spheres & Progression"
  - "Receiving the Divine Love through Prayer"
people: []
spirits: []
keywords: ["laws of God", "limitations", "ordered universe", "Law of Divine Love", "natural love", "purification", "personal responsibility", "soul regeneration", "cycles", "at-onement", "spoon feeding", "harmony", "choices", "awakening", "wisdom"]
questions:
  - "Does God have rules and laws that govern spiritual growth?"
  - "Is the universe truly unlimited or are there spiritual laws we must follow?"
  - "Why can't God just heal me and remove all my pain and error instantly?"
  - "What is my personal responsibility in my own spiritual growth?"
  - "How does the Law of Divine Love differ from other spiritual laws?"
  - "Why do some people seem to progress spiritually so much faster than others?"
  - "What happens to souls who reject God's laws and make up their own rules?"
  - "How do I know when I am choosing the human condition over God's Love?"
  - "Will I eventually understand all of God's laws and how life works?"
  - "Why does God sometimes feel distant even when I am praying?"
  - "Is it possible for God to instantly transform a soul or does it always take time?"
  - "What does it mean to obey God's laws joyfully rather than out of obligation?"
related_messages:
  - 2017-09-12-af-confucius
  - 2017-09-12-af-augustine
  - 2016-05-02-af-andrew
  - 2016-04-12-af-moses
audio_url: ""
canonical_url: "https://divinelovesanctuary.com/understanding-the-laws-of-love-and-the-regeneration-of-our-souls/"
notes: "Third message from the same circle on September 12, 2017, following 2017-09-12-af-confucius and 2017-09-12-af-augustine. Martin Luther opens by referencing the group's conversation that evening. Typo corrected: 'thir intention' to 'their intention'."
significance: ["Key Teaching"]
language: en
excerpt: "To one whose soul is filled with Love, obeying God's Laws is not a burden. It makes perfect sense, and one naturally obeys, for this wisdom comes to the awakened soul."
series: []
last_edited: 2026-04-23
---

I am Martin Luther. I have been listening to your conversation this evening. I see that you have come to a place in which you see there are limitations, that God has placed certain rules in regards to each soul's existence.

Yes, this is a popular belief that the universe is unlimited, that there are no limitations, that mankind may go wherever they wish and that the possibilities are limitless. I must tell you that God has created an ordered universe. In order for all things to function in harmony, there are limitations. What is unlimited is God and one blessing that has no limitations, the outpouring of His Essence, the Divine Love. It is limitless. But even that, as you have read, there will come a time when that possibility has ended. So you see even this opportunity that is so full of God's great and limitless generosity will come to an end at some time in the future.

Does this mean that God does not love His Creation, the souls of mankind? No, my beloveds, God will never cease to love all of His Creation. But there is and there will be cycles and these cycles obey certain laws. The immensity of this manifestation of life, the possibilities of each soul's experience of expression and uniqueness is governed to some degree by the Laws of God. There is one Law that supersedes all others and that is the Law of Divine Love. Even with this blessing within your soul there are limitations and laws which would prescribe a certain way of spiritual growth and awakening.

With the Law of Divine Love, one is able to sidestep many of these conditions that God has laid before each soul in order for it to be purified and come to a place, a point of pristine condition of natural love. When the Divine Love enters the soul in sufficient quantity, there is no need for these efforts to purify the condition of the soul through the effects of natural love. For this purification is enacted in a spontaneous way through the influence of the Love within each soul. Yes, this process may be sped up by your conscious efforts to put aside any conditions that are negative and not in harmony with this Love. We do indeed encourage you to do so, to make a choice for Love and harmony rather than waiting for God and His Blessings to bring this harmony through the power of Divine Love only. This is a possibility. This can be a powerful and swift way of bringing a soul to at-onement with God. But this is not a common experience, for most souls come to God in a very gradual way. So they often have one foot upon the Divine Path and one foot in the human condition. This can create conflict and difficulties, for every soul struggles for Light, every soul is challenged by darkness. But through prayer, by coming to God to receive these great blessings of Love, healing peace and comfort, the soul is uplifted. The soul is given some encouragement and inspiration to seek the Light.

So you continue on your journeys, at times feeling the great blessing and joy of Love and at other times feeling somewhat downtrodden and closer to the condition of humanity. So you go upon your journey and every opportunity is given for you to truly understand, to know and enact the Truths of His Love, the power of this Love within your being and the experience of your life. At times the conditions of this world pull you away because you have chosen to walk in this condition rather than to choose the power of Love. Often you lament to God, sometimes feeling forsaken. This is not the case. You are never forsaken, my beloveds, but you are given a choice. For you to become strong and clear within yourself, resolute, you must acknowledge the choices that you must make in order to bring harmony into your lives or to bring Love into your souls.

The angels cannot spoon feed you forever. This would not facilitate a strengthening of your being. You often waiver back and forth, but the progress continues forward and you become a little stronger with each day. God in His Mercy sends His angels to you. He pours His Healing upon you, His Light infusing you so that you are reminded of what can be, those potentials that are a part of this world and this life. But indeed, even these are limited by your choices. This, too, is a part of life, to truly understand the power of your own choice, the power of your own condition when you do not take into account your actions and the conditions that you harbour within your souls. God does not judge you. God loves you. There is a form of judgment however that comes with your own acknowledgement of those choices that are not altogether in harmony with Love.

It is often the case that a soul desires for God to instantaneously lift them up and heal all the hurts and make good all the error, and that they may not struggle and labour to bring harmony to themselves through their own efforts, desires and prayers. God does not consistently bring a soul to a place of harmony without their personal investment and desire to be in that place of harmony. It takes effort in the case of each individual, it takes desire and motivation. Many turn away because they do not understand their responsibility in the regeneration of the soul, the efforts that must be made, the Laws that must be obeyed for God to respond in Love with the outpouring of His Gift to each soul. That soul must ask for this blessing and must decide that they indeed will seek Light and Truth and acknowledge the power of God's Healing and Blessings that come in prayer. So you see there are Laws in play. God gives this information and knowledge to all who are willing and who desire to know.

For those who make up the rules for themselves and decide this is the truth, this is how things will go, it is folly. For the laws of God have been in place always. It is for mankind to understand, to discover, and to utilize this knowledge to bring to themselves the harmony and joy and spiritual awakening that comes with truly knowing the Truth and understanding the Laws of God, the Laws of Love, the Laws of Creation. There is much to know, my beloveds, much to understand. As you awaken within your souls and trust in the power of God's Love, then all of these awarenesses and understandings will fall into place and will make perfect sense, will not be complex and difficult to understand but made very evident and clear.

Now, each soul has a choice, each soul can accept or reject these Truths. But if their intention is to reject, they do so at their own peril because to live a life without the knowledge of what that life entails is a very precarious course. To live a life with respect for the Laws in which that life is given is a soul full of wisdom and humility. To obey these Laws, to one whose soul is filled with Love is not a burden, but in its way makes perfect sense and one naturally obeys for this wisdom comes to the awakened soul. This wisdom is not lost but enhanced and grows so that all Laws are understood, and life is acted upon with this knowledge. So harmony ensues, the soul awakened and aware and able to see the power of Love, the power of this life, the power of God's Laws working in harmony to bring Light and harmony, peace and goodness to each soul, to each life, to all of creation.

So, my beautiful souls, may you come to know all the rules and laws that govern life and come to accept in joyful awareness how God has created this world and all the universe in a way in which there is harmony, there is beauty, there is Love. As you find your place within this beautiful mechanism of life, within in the flow of your beautiful soul coming into Light and harmony, you will come to know Truth in all its wonderment, all its beauty, all its perfection. This will bring you joy, it will answer all of your questions and will bring the simple Truth to perfect clarity and awareness. You continue to grow in the Love, to open your faculties of the soul so that you may truly see all of these things in all their glory. We will continue to help you to see that you may indeed make those choices that are in harmony with God and be in the flow of His Love and His Will for you. You will understand with such depth and nothing will be a mystery or confusing. But all will come together in harmony and Love. This is what is meant for each soul, to know the Truth, to understand the wonderment of life, and the wonderment of God, and the wonderment of your own being.

So much awaits your awakening and understanding. This shall continue, as God lovingly feeds you with morsels of Truth, morsels of Light. All this beauty and awareness will come in time. May you continue to pray for the Love that fuels the awakening of your soul. You will indeed find the answers that you seek, the awareness that you long for within your soul, the Love that you crave from your Heavenly Father. All will be given as you continue upon this journey. May God bless you mightily, beloved souls, and carry you upon this journey in Love. God bless you. I am Martin Luther. I love you. I love all my brothers and sisters. God bless you.