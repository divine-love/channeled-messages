---
message_id: 2017-01-25-af-alec-gaunt
title: "Building a Foundation of Spiritual Growth and Development"
date: 2017-01-25
spirit_id: alec-gaunt
spirit_name: "Alec Gaunt"
medium: Al Fike
location:
  city: Burnaby
  region: BC
  country: Canada
gathering:
message_type: ["Guidance"]
description: "Alec Gaunt returns to a church he has visited many times both in the flesh and in spirit, urging those gathered to open themselves to the living waters of God's Love and build within themselves the great foundation of a relationship with their Heavenly Father - one that will carry them through every challenge, every joy, and every aspect of their lives."
primary_subjects: "Receiving the Divine Love through Prayer"
secondary_subjects:
  - "Spiritual Discipline & Daily Living"
  - "Circle of Light & Prayer Circles"
  - "Spiritual Empowerment & Encouragement"
people: []
spirits: []
keywords: ["living waters", "foundation", "spiritual growth", "church", "Burnaby", "prayer", "nourishment", "soul", "bond with God", "presence", "healing", "circle of light", "relationship with God", "awakening"]
questions:
  - "How do I build a solid foundation for my spiritual life?"
  - "How do I open myself to receive God's Love?"
  - "What does it feel like to have a deep relationship with God?"
  - "How do I refresh and nourish my soul?"
  - "How do I pray in a way that truly connects me with God?"
  - "How does God's Love carry me through the difficult parts of my life?"
  - "How do I know God is with me even when life is hard?"
  - "What is the greatest fulfillment a soul can experience?"
  - "How do I bring the light of God's Love into my community?"
related_messages:
  - 2015-05-27-af-alec-gaunt
  - 2015-09-30-af-alec-gaunt
  - 2016-04-27-af-alec-gaunt
audio_url: ""
canonical_url: "https://divinelovesanctuary.com/building-a-foundation-of-spiritual-growth-and-development/"
notes: "Alec mentions having visited this church many times both in the flesh and in spirit, indicating a long-standing connection to the Burnaby spiritual community."
significance: []
language: en
excerpt: "You are building a great foundation within you as you continue to pursue your spiritual growth and development. God will be with you and you will feel the strength and the comfort and the joy of this presence, always."
series: []
last_edited: 2026-04-23
---

I am Alec and I have come to this church many times over the many years I have had an association here. I have come in the flesh. I have come in spirit. I have worked with many of you who are here. I come to serve God in love, in my desire to support you in your spiritual development. Beloved souls, do you not feel these living waters pouring over you, this blessing of God's Love, washing over you, through you, carrying you to another place in light? Beloved souls open yourselves to this blessing. Allow God to lift you up and bring you to that place of peace, and joy, comfort, healing and love. So many in your world do not know how to refresh themselves in this way, to reach out to God in prayer and supplication, in openness and humility, to seek this nourishment from the Creator, to carry this light wherever they go. Beloved souls this is available to each and every one of you and to each and everyone in this world if they but take the time and make their prayers be known to God and open themselves to that touch, that step in faith that says, "I am with you. I love you. Dear God be with me that I might feel your love. Be with me that your peace may rest as a mantle upon me. Be with me so that I know I am never alone, that you are with me always."

Oh my friends, you are building a great foundation within you as you continue to pursue your spiritual growth and development, as you seek truth, as you understand the breadth and depth of love and the power of love to heal and unite and bring grace into your lives. It is here now this blessed light, these living waters. Drink deep my friends. This is the great nourishment that your soul hungers for. It thirsts for these waters. It desires to be nurtured, to grow in this great love that ignites the soul to deep awarenesses, profound change, and beautiful awakenings. Where God has a powerful presence within as His Love, His Essence grows within you, so the bond between you and the Creator grows, expands and becomes a solid palpable thing. In your lives this relationship will carry you through every part of your life, every challenge you have, every aspect of your life, whether it be joyful or sad, difficult, or fulfilling, God will be there. God will be with you and you will feel the strength and a comfort and the joy of this presence – always.

I urge you my beloved friends, open your souls whenever you may, whenever it is possible. Make this simple prayer. Reach out to God in this simple way with a longing and a desire to receive this essence, this blessing and to be with God. To be with God, this is the greatest fulfillment you may experience. The most wondrous awakening. The deepest healing that comes in this relationship with your Heavenly Father. God bless you my friends.

Thank you all for being here in this way, for bringing light to this world in this prayer and how God can use this light in so many ways to benefit many in your world. Continue to do so my beloved friends, to come together in this loving way and bringing this circle of light with you, amongst you as it flows out into this world. God bless you. I am Alec and my blessings and love go with you my beloveds. God bless you.