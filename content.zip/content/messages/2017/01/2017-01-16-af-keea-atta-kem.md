---
message_id: 2017-01-16-af-keea-atta-kem
title: "Accept Every Unique Soul: Their Differences Will Not Harm You Spiritually"
date: 2017-01-16
spirit_id: keea-atta-kem
spirit_name: "Keea atta Kem"
medium: Al Fike
location:
  city: Gibsons
  region: BC
  country: Canada
gathering:
message_type: ["Teaching"]
description: "Keea atta Kem addresses the anxiety of spiritually sensitive souls who feel affected by the world's conditions, teaching that increased sensitivity is a natural sign of soul growth, that thoughts attract like energies by law, and that the Love within a growing soul provides powerful protection — so there is no need for fear, only joyful acceptance of each unique soul walking their own path toward God."
primary_subjects: "Spiritual Identity & Destiny"
secondary_subjects:
  - "Earthly Challenges & Human Condition"
  - "Self-Love & Acceptance"
  - "Celestial Governance & Spiritual Law"
  - "Walking the Divine Path"
people: []
spirits: []
keywords: ["sensitivity", "spiritual protection", "law of attraction", "thoughts", "conditions", "fear", "acceptance", "unique souls", "free will", "Divine Path", "immunity", "clouds and sun", "judgment", "channel of love", "equilibrium"]
questions:
  - "Why do I feel so affected by other people's energy?"
  - "Is it normal to become more sensitive as I grow spiritually?"
  - "How do I protect myself from negative energies and conditions?"
  - "Do my thoughts really attract negative energies?"
  - "How do I stop judging people who are on a different spiritual path?"
  - "How do I stay in the Light when the world around me feels dark?"
  - "Can negative conditions permanently damage my soul's progress?"
  - "How do I love and accept souls who carry difficult or dark conditions?"
  - "What is the law of attraction and how does it work spiritually?"
  - "How do I neutralise negative conditions through prayer?"
  - "Is spiritual sensitivity a gift or a burden?"
  - "How do I allow others to walk their own path without feeling responsible for them?"
related_messages:
  - 2016-04-04-af-keea-atta-kem
  - 2016-04-13-af-seretta-kem
  - 2016-07-10-af-augustine
audio_url: ""
canonical_url: "https://divinelovesanctuary.com/accept-every-unique-soul-differences-will-not-harm-spiritually/"
notes: "Correction: 'not for you to obsessed about' corrected to 'not for you to be obsessed about'. Double space before 'obsessed' also corrected."
significance: []
language: en
excerpt: "Just as upon a sunny day the clouds obscure the sun and bring a small shadow — these clouds will move on and the sun returns. So it is with your condition as you sit with God."
series: []
last_edited: 2026-04-23
---

Thank you for coming, for you were called. And your discussion of the morning was very good indeed, sharing your concerns and your perceptions, your ideas and your aspirations. This is good. It is good to reveal your inner thoughts and ideas, to bring forth what it is that is broiling about within your mind, your souls.

As for these dilemmas, the dilemmas that you perceive as you reach out to many souls in this world, indeed, it would be easy to enwrap your group in a safe cocoon of love, going to your Heavenly Father, receiving His gifts and blessings of Love, and in this experience not encountering any challenge or difficulty.

Yes, I know this is what you desire in many ways and there is nothing untoward in this desire. You are children who wish to be fed. You long for the succour of Love. You desire to reach ever higher within this Light and Love, to be strong and filled with this Elixir, to feel the joy of it, to know the peace of it, to be in harmony with God. And you are merely doing what has been asked and encouraged of you, and what your soul longs for, to be with God in this beautiful time that you set aside to be with God. How important and how crucial this is in your own soul's progression, this sacred time with your Heavenly Father.

Then there are times when you must reach out to others. This world has many, many conditions, variations, thoughts, energies, beliefs, religions, cultures. You cannot go out your door and be immune to these conditions and energies completely. No, my beloveds, you will encounter and you will come in close proximity to many of these conditions in the world. Where there is an influence, a mark is made with these encounters, and the more sensitive you are as you open and progress in the Divine Love, as your souls grow, as you change and come into more of an equilibrium between your souls and your mind, you obtain certain sensitivities. You perceive these various conditions and you are aware how there is to some degree an effect upon your condition. This is inevitable, my beloveds, that you will be affected by those conditions that are not of Love, that are not of Divine Love.

This does not mean that you are diverted from the Divine Path. This does not mean that you are assaulted by these conditions. No, my beloveds, it just means that you are aware and in your spiritual maturity you know how these conditions, if they do affect you, can be neutralised with prayer. And for those thoughts that are negative and not of the highest, you are responsible for your own thoughts, my beloveds. And though they may, to some degree, be influenced by outside sources, this does not mean that you are a victim of these things. No, my beloveds, you are responsible and you must take measures to protect yourself and discipline yourself within your minds regarding your thoughts.

Thoughts do indeed attract and bring like energies close. This is a Law and this Law comes into effect whether you are aware of it or not. You must be cognizant of its effects and its workings. As you are close to God, so your thoughts are elevated and your motives, your aspirations, your actions are all influenced by the power of the Love residing within your soul. How powerful is this Love, how healing is this Love, how beautiful is this Love that resides within you, my beloveds.

Do not feel fear for the conditions that are around you and the conditions others carry within them. No, my beloveds, when you are a channel of God's Love, when you are aligned with God there may be some peripheral effect upon your being, but nothing that is permanent, nothing that is damaging. It is but an experience of life, an experience that comes with greater sensitivity and is not for you to be obsessed about, nor a source of fear and worry. No, my beloveds, it is important to understand that with the Love within your souls, with those conditions generated by this Love, you are indeed in the light. If you did not have this blessing within you and you did not build these conditions from your prayers and your desires of the soul, those wayward conditions that are difficult and negative would be a part of your everyday life. You would be expressing and reinforcing these negative energies in your life to some degree or another, depending upon your choices. With the blessing of God's Love, you have a great deal of immunity and protections from these conditions.

So, my beloveds, do not fear or worry. Do not have concerns in this regard. As long as you maintain your connection with God and you continue to grow in this Love, you will be protected. And know just as upon a sunny day, at times the clouds obscure the sun and bring a small shadow into your lives, these clouds will move on and the sun returns. So, it is with your condition, your perception of your reality of the moment. It changes, it changes with the variations of the conditions that surround you. And yet, as you sit and be with God, the sun does indeed come out and fills you with that joy, that relief, that clarity of light.

Rejoice that you are a child of God and rather than be immersed in the chaotic conditions of the world, you are embraced by God. You shall continue to be embraced by God. Be joyful, my beloveds, and know how loved you are, how beautiful is your life. Despite the wayward conditions of the world you continue to be in the light. You are nurtured by God, surrounded by His Angels. Your soul is growing in the wonderful light of God's Love. What more can you ask for, my beloveds? How wonderful is the blessing of your life, lived within the Light of God's Love? All else will fall away in time. And there will come a time that although you will be sensitive to these conditions they will not affect you whatsoever. You are beginning to learn how to deal with these conditions as they come along on your path. You are learning to not judge those who you find different in this world. You are learning how to truly love, to accept, to embrace with love; to allow the individual soul to walk their individual paths in love. What strength and wisdom this is, my beloveds, to truly allow this without judgment, without fear. And though you may sense the differences, you understand within your souls that there is beauty in the variations of God's Creation.

Each soul walks their path towards God. They are given the blessing of Free Will, the freedom to choose and the opportunity to recognize those choices, my beloveds. And as you walk your path, shining within the truth of God's Love, you offer to those you encounter an opportunity to see this truth manifest in you, in your beautiful soul. And this is what you must do in your lives, my beloveds, to be that example, that truth, that joyful acknowledgement that God is indeed Love. You, my beloveds, carry that Love within you and whether others choose to adopt this truth, to live this truth is not for you to be concerned with. It is for you to live this truth and walk this truth and express this truth as best you can. That it may shine through all the wonderful facets of your being into your life. And in this beautiful way, others will be drawn and you will be able, as God's channels of Love, to touch many souls.

There is no need to worry about the differences in those you encounter. Be accepting and loving. Your feet are firmly planted upon the Divine Path, walking joyfully towards God, accepting that your path is your unique journey and others are experiencing their journey upon the road of their life. Be content with this, my beloveds, allow this to be, for this is truly loving. Beloved souls, I am Keea. I love you. Bless you.