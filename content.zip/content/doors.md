---
title: "The Doors"
description: "Augustine teaches that hidden within each channeled message is a great door to growing your souls and making yourselves a clearer channel of Love in the world. This index collects those doors - one per message - as an invitation to enter."
last_updated: 2026-04-23
---

# The Doors

> "Remember the words we have spoken to you, beloveds. Contemplate these words, these teachings, for hidden within each lesson is a great door to growing your souls and making yourselves a clearer channel of Love in the world."
> — Augustine, April 19, 2016

---

| Message | Spirit | Date | The Door |
|---|---|---|---|
| [Jesus' Birth and Youth](messages/1963/12/1963-12-26-ds-mary.md) | Mary | 1963-12-26 | A mother's grief strips away doctrine and leaves only the truth she lived |
| [Free Will Makes for a Free Wheeling World. Nothing Is Guaranteed.](messages/2014/07/2014-07-26-af-augustine.md) | Augustine | 2014-07-26 | Freedom to choose is the very thing that makes love real |
| [You Will Never Feel the Pain of Being Alone When You Possess God's Love](messages/2014/10/2014-10-11-af-confucius.md) | Confucius | 2014-10-11 | The loneliness you feel is a signpost pointing toward the Love that ends it |
| [Every Soul Can Receive the Divine Love and Be Transformed by It](messages/2014/10/2014-10-11-af-judas.md) | Judas | 2014-10-11 | If Judas can be redeemed, no soul is beyond the reach of God's Love |
| [Express Your Yearnings to God](messages/2014/12/2014-12-01-af-john-the-beloved.md) | John the Beloved | 2014-12-01 | Your longing is already a prayer and God hears it before you find the words |
| [Use Your Gift of Life to the Most Advantage](messages/2014/12/2014-12-15-af-mary.md) | Mary | 2014-12-15 | Self-judgment is the one thing standing between you and the joy God intends for you |
| [Cleansing of Your Soul Brings Understanding, Perception and Wisdom](messages/2015/01/2015-01-05-af-andrew.md) | Andrew | 2015-01-05 | The pain of cleansing is the price of a wisdom that cannot be learned any other way |
| [The Desires of Your Soul to Be in the Light](messages/2015/01/2015-01-05-af-mary.md) | Mary | 2015-01-05 | The deepest desire of your soul is already pointed toward God |
| [You Are Deeply Needed](messages/2015/01/2015-01-05-xx-jesus.md) | Jesus | 2015-01-05 | You are not incidental to God's plan. You are needed |
| [Treasures Uncovered](messages/2015/05/2015-05-18-af-andrew.md) | Andrew | 2015-05-18 | The gifts within you are not waiting to be earned. They are waiting to be uncovered |
| [Recognizing Your Two Selves, the Soul and the Material Mind](messages/2015/05/2015-05-18-af-augustine.md) | Augustine | 2015-05-18 | You are not your mind. Your soul is a different and deeper self entirely |
| [After All Your Preparations It Is Time to Step Forward](messages/2015/05/2015-05-27-af-alec-gaunt.md) | Alec Gaunt | 2015-05-27 | The season of preparation is over. It is time to act |
| [Change Within Is Coming as Your Souls Grow in the Love](messages/2015/05/2015-05-27-af-confucius.md) | Confucius | 2015-05-27 | The change you feel stirring within is not disruption. It is growth |
| [A Walk in the Garden](messages/2015/05/2015-05-27-af-goldie.md) | Goldie | 2015-05-27 | Joy does not wait for perfection. It lives in a walk in the garden right now |
| [Overcome the Darkness with an Attitude of Light, Joy and Appreciation](messages/2015/05/2015-05-27-af-james.md) | James | 2015-05-27 | Gratitude is not passive. It is one of the most powerful forces against darkness |
| [Complying to the Will of God](messages/2015/06/2015-06-01-af-augustine.md) | Augustine | 2015-06-01 | Surrender to God's Will is not defeat. It is the beginning of your true life |
| [You Walk Towards At-Onement with God](messages/2015/06/2015-06-01-af-jesus.md) | Jesus | 2015-06-01 | Every step you take, however small, is bringing you closer to God |
| [Joseph Speaks to Newcomers to the Prayer Circle](messages/2015/06/2015-06-08-af-joseph.md) | Joseph | 2015-06-08 | The natural love path and the Divine Love path lead to very different destinations |
| [As You Think of Your Loved Ones in Your Prayers, They Will Be Blessed](messages/2015/06/2015-06-08-af-mary.md) | Mary | 2015-06-08 | Prayer for those you love reaches them even when your words cannot |
| [Understand and Follow the Will of God](messages/2015/06/2015-06-12-af-alec-gaunt.md) | Alec Gaunt | 2015-06-12 | God's Will is stronger than any human will, including your own resistance |
| [The Many Benefits of Praying in a Circle of Light](messages/2015/06/2015-06-13-af-confucius.md) | Confucius | 2015-06-13 | When souls pray together their Light multiplies beyond what any one could generate alone |
| [Embrace Those That Are Coming and Embrace the Flow of God's Love](messages/2015/06/2015-06-14-af-augustine.md) | Augustine | 2015-06-14 | The doors God opens are not always the ones you were expecting |
| [The Metaphor of the Bruised Apple](messages/2015/06/2015-06-21-af-augustine.md) | Augustine | 2015-06-21 | What looks bruised and damaged to you may be exactly what God is healing from the inside |
| [Goldie Affirms Her Presence at a Garden Club Lecture](messages/2015/06/2015-06-21-af-goldie.md) | Goldie | 2015-06-21 | The spirit world is closer to your everyday life than you think |
| [God's Will Is above Man's Will](messages/2015/06/2015-06-21-af-martin-luther.md) | Martin Luther | 2015-06-21 | Religious error can be held sincerely, and sincerely held error still needs to be released |
| [Every Soul Has a Purpose and Gift to Bring into the World](messages/2015/06/2015-06-24-af-confucius.md) | Confucius | 2015-06-24 | Your unique purpose is not something you have to invent. It is something you have to discover |
| [Release the Pains of Your Soul, for God Needs You to Be Strong and Clear](messages/2015/06/2015-06-29-af-alec-gaunt.md) | Alec Gaunt | 2015-06-29 | God cannot fully use you until you are willing to let Him heal the places you are still protecting |
| [Guidance Concerning the Upcoming Retreat: Embrace All Who Are Coming](messages/2015/07/2015-07-06-af-augustine.md) | Augustine | 2015-07-06 | Every soul who comes to you is sent. Receive them accordingly |
| [How Your Soul Is Changed by the Love](messages/2015/07/2015-07-20-af-confucius.md) | Confucius | 2015-07-20 | Divine Love does not just comfort the soul. It fundamentally changes its nature |
| [Pray for the Children](messages/2015/07/2015-07-20-af-mary.md) | Mary | 2015-07-20 | The children of the world carry the seeds of the next generation of Light |
| [A Door Opens: Will You Enter through Its Threshold?](messages/2015/07/2015-07-21-af-augustine.md) | Augustine | 2015-07-21 | The door is already open. The only question is whether you will walk through it |
| [Guidance Regarding the Retreat That Is about to Take Place](messages/2015/07/2015-07-27-af-augustine.md) | Augustine | 2015-07-27 | What God prepares for a gathering of souls is far greater than what any one of them imagined |
| [Stand Up and Walk with Me](messages/2015/07/2015-07-27-af-jesus.md) | Jesus | 2015-07-27 | Jesus is not a figure in a story. He is present, and he is asking you to walk with him now |
| [Release Those Conditions Within You That Hold You Back](messages/2015/08/2015-08-03-af-augustine.md) | Augustine | 2015-08-03 | The conditions holding you back are not permanent. They are ready to be released |
| [Many Gifts Lie Within](messages/2015/08/2015-08-03-af-confucius.md) | Confucius | 2015-08-03 | The gifts you have been given are already within you, waiting to be recognised |
| [Follow the Sweet Yearnings of the Soul So That You May Know Truth](messages/2015/08/2015-08-03-af-john-the-beloved.md) | John the Beloved | 2015-08-03 | The sweet yearning you feel is your soul showing you the way to Truth |
| [Blessings to Help Those Who Are Engaged in the Larger Circle of Light](messages/2015/08/2015-08-14-af-james.md) | James | 2015-08-14 | Your prayers reach far beyond the room you are sitting in |
| [Speaking to a Divine Love Retreat Group: Be Open to New Possibilities](messages/2015/08/2015-08-15-af-augustine.md) | Augustine | 2015-08-15 | God is always opening new possibilities. Your only task is to remain open |
| [Jesus Greets Those Gathered in Retreat: Reiterates His Calling to Be His Disciples](messages/2015/08/2015-08-15-af-jesus.md) | Jesus | 2015-08-15 | Discipleship is not a title. It is a daily choice to walk in Love |
| [The Chain of Love](messages/2015/08/2015-08-15-af-mary.md) | Mary | 2015-08-15 | Every soul who receives God's Love becomes a link in a chain that circles the world |
| [Jesus Speaks Seriously of Changes to Come: Be a Channel of Love through the Storms](messages/2015/08/2015-08-17-af-jesus.md) | Jesus | 2015-08-17 | The storms are coming, and a soul grounded in Love is the safest place to stand |
| [Seek out Your True Purpose](messages/2015/08/2015-08-17-af-peter.md) | Peter | 2015-08-17 | Your true purpose is not something you choose. God placed it in your soul before you were born |
| [Andrew Encourages All to Bring the Truth of God's Love Forward](messages/2015/08/2015-08-20-af-andrew.md) | Andrew | 2015-08-20 | God guided you to this truth through an unremarkable moment. Trust Him to do the same for others |
| [Express the Truth to Others: Padgett Talks of Why This Is So Important](messages/2015/08/2015-08-20-af-james-padgett.md) | James Padgett | 2015-08-20 | The truth you carry is needed, and the world cannot hear it if you keep it to yourself |
| [Keea Instructs a Group to Go to Their Souls and Live from That Place Rather Than the Material Mind](messages/2015/08/2015-08-20-af-keea-atta-kem.md) | Keea atta Kem | 2015-08-20 | Your soul already knows what your mind is still arguing about |
| [Give to Others but Do Not Do so with an Empty Basket](messages/2015/08/2015-08-20-af-martin-luther.md) | Martin Luther | 2015-08-20 | You cannot give what you do not have. Fill yourself with Love before you try to fill others |
| [The Change That Is Coming Will Start with the Children](messages/2015/08/2015-08-20-af-mary.md) | Mary | 2015-08-20 | The transformation of the world will begin with its youngest souls |
| [Be Open to His Love](messages/2015/08/2015-08-21-af-andrew.md) | Andrew | 2015-08-21 | Openness is not passive. It is an active choice to receive what God is already offering |
| [Augustine Advises a Retreat Group to Talk about Their Inner Soul Changes](messages/2015/08/2015-08-22-af-augustine.md) | Augustine | 2015-08-22 | Sharing your inner changes with others is itself an act of Love and courage |
| [Confucius Urges Group Participants to Start Circles of Light Where They Live](messages/2015/08/2015-08-22-af-confucius.md) | Confucius | 2015-08-22 | Every city, every town, every home can become a point of Light in the world |
| [Jesus Gives His Blessing to Those in the Retreat](messages/2015/08/2015-08-22-af-jesus.md) | Jesus | 2015-08-22 | The blessing of Jesus is not a formal ceremony. It is a living, personal touch |
| [John Gives a Prayer for Greater Enlightenment](messages/2015/08/2015-08-22-af-john-the-beloved.md) | John the Beloved | 2015-08-22 | Prayer is not a petition to a distant God. It is communion with One who is already present |
| [Nurture the Children](messages/2015/08/2015-08-22-af-mary.md) | Mary | 2015-08-22 | The children around you are not incidental. They are your first and most important mission field |
| [Many Angels Give Their Message of Reassurance and Comfort to a Group Which Came Together for a Prayer Retreat](messages/2015/08/2015-08-23-af-jesus.md) | Jesus | 2015-08-23 | You are not alone. Ten celestial spirits stand with you as you go back into the world |
| [Material Manifestations Will Come in Time](messages/2015/08/2015-08-24-af-seretta-kem.md) | Seretta Kem | 2015-08-24 | The most powerful healing manifestation is not a miracle. It is Love |
| [Words of Encouragement to Two Divine Love Followers](messages/2015/08/2015-08-27-af-mark.md) | Mark | 2015-08-27 | Your compassion for others is itself evidence of the Love within your soul |
| [Work Together in Love](messages/2015/08/2015-08-28-af-augustine.md) | Augustine | 2015-08-28 | Working together in Love creates something none of you could create alone |
| [Be a Light and Take Part in the Plan for the Salvation of Mankind](messages/2015/08/2015-08-28-af-jesus.md) | Jesus | 2015-08-28 | You have been invited into God's plan for the world, not as a spectator but as a participant |
| [The World Is Changing and Needs Many Souls in Service to God's Will](messages/2015/08/2015-08-31-af-seretta-kem.md) | Seretta Kem | 2015-08-31 | The world's need for souls in service is urgent, and you already have what it takes |
| [Like a Newborn, the Eyes of Your Soul Begin to Open Bringing Shifts and Changes of Perception](messages/2015/09/2015-09-07-af-augustine.md) | Augustine | 2015-09-07 | The disorientation you feel is not confusion. It is your soul's eyes learning to see |
| [Take Time to Come to Firmer Ground](messages/2015/09/2015-09-07-af-confucius.md) | Confucius | 2015-09-07 | Stillness is not inaction. It is the foundation from which all true action comes |
| [His Love Clears away the Shadows and the Mists, Allowing You to Know Your Own Souls](messages/2015/09/2015-09-27-af-augustine.md) | Augustine | 2015-09-27 | The fog that obscures your soul is not permanent. Love is already clearing it |
| [The Wondrous Expressions of Your Soul and Life's Challenges](messages/2015/09/2015-09-27-af-faith-nyquist.md) | Faith | 2015-09-27 | God is never disappointed in you. Only your own expectations disappoint you |
| [Go Within in Order to Know God's Will for You](messages/2015/09/2015-09-30-af-alec-gaunt.md) | Alec Gaunt | 2015-09-30 | The answers you are seeking from others are already within you |
| [Cherish This Light](messages/2015/10/2015-10-05-af-augustine.md) | Augustine | 2015-10-05 | The Light within you is precious. Treat it accordingly |
| [Journey upon the Waters of Life Together](messages/2015/10/2015-10-05-af-moses.md) | Moses | 2015-10-05 | The journey is not meant to be walked alone. God sends companions for a reason |
| [Continue to Love](messages/2015/10/2015-10-12-af-john-the-beloved.md) | John the Beloved | 2015-10-12 | When everything else is uncertain, continuing to love is always the right next step |
| [These Are the Days to Learn How to Love](messages/2015/10/2015-10-19-af-augustine.md) | Augustine | 2015-10-19 | You are living in the very days that matter most, and learning to love is the work of these days |
| [You Are Becoming God's Instruments and Channels of Love](messages/2015/10/2015-10-19-af-john-the-beloved.md) | John the Beloved | 2015-10-19 | Becoming a channel of Love is not a destination. It is a continuous unfolding |
| [The First Father Talks about Reincarnation and the Progression of Life](messages/2015/10/2015-10-26-af-aman.md) | Aman | 2015-10-26 | You incarnate once, and that one life sets the trajectory of an eternal journey |
| [So Many in the Unseen World Benefit from Your Prayers Together](messages/2015/10/2015-10-26-af-seretta-kem.md) | Seretta Kem | 2015-10-26 | Your prayers reach into the spirit world and bring healing to souls you will never meet in this life |
| [Free Will Governs Your Path](messages/2015/11/2015-11-02-af-augustine.md) | Augustine | 2015-11-02 | Free will is not a burden. It is the dignity God gave you to choose Love |
| [Release the Yoke of Error and Lack of Self Love](messages/2015/11/2015-11-02-af-john-the-beloved.md) | John the Beloved | 2015-11-02 | The yoke you are carrying was never meant for you. It can be laid down |
| [Healing for This Precious World Is Required](messages/2015/11/2015-11-09-af-francis-of-assisi.md) | Francis of Assisi | 2015-11-09 | The world is not beyond healing, but it needs souls willing to be instruments of that healing |
| [Do Not Hide Away but Express Your Gifts in the World](messages/2015/11/2015-11-16-af-alec-gaunt.md) | Alec Gaunt | 2015-11-16 | Hiding your gifts is not humility. It is withholding blessings from those who need them |
| [It Shall Start in the West and Move Around the World](messages/2015/11/2015-11-23-af-jesus.md) | Jesus | 2015-11-23 | The awakening of humanity has already begun, and it started where you are standing |
| [Prayer to Bring Freedom and Joy](messages/2015/11/2015-11-28-af-confucius.md) | Confucius | 2015-11-28 | Prayer is not an obligation. It is the most direct path to freedom and joy |
| [Encouragement to Form Circles of Light](messages/2015/11/2015-11-28-af-mary.md) | Mary | 2015-11-28 | Every Circle of Light you form sends ripples of healing far beyond what you can see |
| [Healing Merkaba](messages/2015/11/2015-11-28-af-seretta-kem.md) | Seretta Kem | 2015-11-28 | When souls join hands in prayer, they share not just intention but their very being |
| [Express Joy in the World](messages/2015/11/2015-11-30-af-goldie.md) | Goldie | 2015-11-30 | With a touch and a smile and a glint in your eye, you can be a channel of Love for all you meet |
| [Consecration of Your Journey to God](messages/2015/11/2015-11-30-af-jesus.md) | Jesus | 2015-11-30 | Consecrating your life to God is not a sacrifice. It is the discovery of your true purpose |
| [Carry This Light into the Darkened World](messages/2015/12/2015-12-07-af-augustine.md) | Augustine | 2015-12-07 | Carry it held high with Love and with the sure knowledge that God has touched your souls |
| [Drink Deep from the Living Waters](messages/2015/12/2015-12-07-af-john-the-beloved.md) | John the Beloved | 2015-12-07 | Drink deep these Living waters and open yourselves wide. It is yours, a Gift, a blessing, a touch |
| [Free Will versus God's Will](messages/2015/12/2015-12-14-af-augustine.md) | Augustine | 2015-12-14 | You cannot know God's Will from your mind. You can only know it from your soul |
| [The Emerging Growth of Your Souls](messages/2015/12/2015-12-14-af-faith-nyquist.md) | Faith | 2015-12-14 | You cannot turn back. You can only move forward in Love |
| [God Will Ask Much of You in the Coming Year](messages/2015/12/2015-12-21-af-peter.md) | Peter | 2015-12-21 | The world will enter a time of great difficulty and you must be on the ready |
| [Awakening of the Soul Mind](messages/2015/12/2015-12-27-af-augustine.md) | Augustine | 2015-12-27 | The soul mind is awakening within you, like a newborn whose vision is blurry but becoming clear |
| [Accepting the New Awarenesses of an Opening Soul](messages/2016/01/2016-01-04-af-confucius.md) | Confucius | 2016-01-04 | There may be nothing between your mind and your soul - a merging of consciousness |
| [You Struggle But You Make Progress](messages/2016/02/2016-02-29-af-confucius.md) | Confucius | 2016-02-29 | The struggle is not a sign that something is wrong. It is proof that something is growing |
| [Talk on Service to God](messages/2016/03/2016-03-18-af-john-the-beloved.md) | John the Beloved | 2016-03-18 | You and God are bonded for all eternity and you shall continue to serve Him in ever greater ways |
| [The Awakening of Humanity](messages/2016/03/2016-03-21-af-augustine.md) | Augustine | 2016-03-21 | You are the first tender shoots of a spring that is dawning for all of mankind |
| [Talk on Service](messages/2016/03/2016-03-26-af-andrew.md) | Andrew | 2016-03-26 | There is a deep recognition within you that you are meant to love and to be a channel of Love |
| [The Gift of Life](messages/2016/03/2016-03-29-af-james.md) | James | 2016-03-29 | To know your soul and to know who you truly are is the greatest of all gifts to yourself |
| [A Lesson on the Power of Humility](messages/2016/03/2016-03-30-af-augustine.md) | Augustine | 2016-03-30 | True power is not control. It is the strength that comes from letting God flow through you unrestricted |
| [In Knowing and Growing Your Soul, You Will Find Your True Self](messages/2016/04/2016-04-04-af-jesus.md) | Jesus | 2016-04-04 | You are a gift to the world. As you truly love yourselves, oh what wonders your Heavenly Father may manifest through you |
| [The Prism of Our Souls](messages/2016/04/2016-04-04-af-keea-atta-kem.md) | Keea atta Kem | 2016-04-04 | The light within your soul refracts through the prism of God's Love, each colour a unique gift |
| [Talk on Compassion and Service](messages/2016/04/2016-04-05-af-gandhi.md) | Gandhi | 2016-04-05 | Everyone hungers for love. Prepare a feast for the starving soul |
| [Expectations of the Mind: On Releasing Control](messages/2016/04/2016-04-12-af-augustine.md) | Augustine | 2016-04-12 | Think how much freedom you will obtain by simply letting go |
| [Lesson on the Falsity of the Vicarious Atonement and the Unsure Nature of Written Truth](messages/2016/04/2016-04-12-af-moses.md) | Moses | 2016-04-12 | The word is not sacred. What is sacred is your living connection with your Heavenly Father |
| [The Greatest Healing Energy of All Is God's Divine Love](messages/2016/04/2016-04-13-af-seretta-kem.md) | Seretta Kem | 2016-04-13 | There is only one blessing that cannot be given from one person to another. It must come directly from God |
| [Nurture Those You Encounter](messages/2016/04/2016-04-14-af-mary.md) | Mary | 2016-04-14 | God places within the souls of those you touch a desire for His Love, and this is powerful |
| [Each Day Has the Potential to Bring Light Given the Right Intentions](messages/2016/04/2016-04-14-af-john-the-beloved.md) | John the Beloved | 2016-04-14 | Like the butterfly that flutters its wings and creates the hurricane, these tiny flutters of Light will create change |
| [You Will Come Together Again](messages/2016/04/2016-04-19-af-augustine.md) | Augustine | 2016-04-19 | Hidden within each lesson is a great door to growing your souls |
| [The Law of Change](messages/2016/04/2016-04-27-af-alec-gaunt.md) | Alec Gaunt | 2016-04-27 | Change itself is the path, not an obstacle to it |
| [Two Paths Towards Love and Purification](messages/2016/05/2016-05-02-af-andrew.md) | Andrew | 2016-05-02 | You are already building your eternal home with every prayer you say today |
| [Walk with Me in This Light](messages/2016/05/2016-05-11-af-jesus.md) | Jesus | 2016-05-11 | The prayer itself, offered by Jesus as a living invitation |
| [Aman Speaks of the Original State of Humanity and the Fall from Grace](messages/2016/05/2016-05-29-af-aman.md) | Aman | 2016-05-29 | The choice refused at the beginning of time is being offered again, and this time we can choose differently |
| [Breaking Free of the Shell Around Your Soul](messages/2016/06/2016-06-13-af-james.md) | James | 2016-06-13 | You are already in the process of being reborn. The struggle you feel is the shell cracking, not failure |
| [You Will Fulfill Your Mandate to Be a Channel of Love at My Home](messages/2016/06/2016-06-27-af-brother-mandus.md) | Brother Mandus | 2016-06-27 | What is needed is not a strong personality but a humble, prayerful soul |
| [Love Is the True Currency of Life](messages/2016/07/2016-07-04-af-francis-of-assisi.md) | Francis of Assisi | 2016-07-04 | Love is not something to find outside yourself. It is something God pours in when you simply ask |
| [The Awakened Soul](messages/2016/07/2016-07-09-af-confucius.md) | Confucius | 2016-07-09 | The awakened soul understands Truth in ways the mind simply cannot |
| [Nurturing the Mind or the Soul: It's a Choice](messages/2016/07/2016-07-10-af-augustine.md) | Augustine | 2016-07-10 | The yearning itself is the prayer, and the crack in the armor of the mind is where God enters |
| [You Will All Be Instrumental on the Path](messages/2016/08/2016-08-15-af-mary.md) | Mary | 2016-08-15 | You are standing on the threshold of a great work already begun |
| [Express the Potentials of Your Awakening Souls](messages/2016/08/2016-08-16-af-james.md) | James | 2016-08-16 | The treasure house of your soul's gifts is already there, waiting to be discovered |
| [The Minds of Men Hunger for the Reality that Words Create but the Soul Hungers for Love](messages/2016/08/2016-08-17-af-james-padgett.md) | James Padgett | 2016-08-17 | Your unique story of Love is all you need, and your embrace will touch souls your words alone never could |
| [The World Needs Your Prayers](messages/2016/12/2016-12-02-af-white-cloud.md) | White Cloud | 2016-12-02 | Love is not the soft option. It is the most powerful force in the universe |
| [Talk on Mediumship: The Laws of Communication and Rapport](messages/2016/12/2016-12-06-af-seretta-kem.md) | Seretta Kem | 2016-12-06 | The gift of Divine Love received wordlessly in prayer is greater than any message from a spirit |
| [Be Calm in the Coming Storms](messages/2016/12/2016-12-07-af-andrew.md) | Andrew | 2016-12-07 | In any storm, the soul that is calm is the one others turn to |
| [Time to Accept a New Way of Being](messages/2016/12/2016-12-29-af-matthew.md) | Matthew | 2016-12-29 | The reality you have built in your mind is not the only reality. Letting go of it is liberation, not loss |
| [The Road Is Clear Before You](messages/2017/01/2017-01-02-af-jesus.md) | Jesus | 2017-01-02 | The road is already clear. The only obstructions are the ones you create yourself |
| [Accept Every Unique Soul: Their Differences Will Not Harm You Spiritually](messages/2017/01/2017-01-16-af-keea-atta-kem.md) | Keea atta Kem | 2017-01-16 | Sensitivity is a sign of growth, not vulnerability, and the Love within you is stronger than anything you encounter outside |
| [Changes Within Your Soul Will Bring Many Rewards](messages/2017/01/2017-01-23-af-alec-gaunt.md) | Alec Gaunt | 2017-01-23 | The outward self you cling to is a paper tiger. Your true self, with all its gifts and treasures, is waiting inside your soul |
| [Building a Foundation of Spiritual Growth and Development](messages/2017/01/2017-01-25-af-alec-gaunt.md) | Alec Gaunt | 2017-01-25 | The greatest fulfillment your soul can experience is simply to be with God |
| [Release Self-Will and Embrace the Perfect Will of God](messages/2017/03/2017-03-27-af-james.md) | James | 2017-03-27 | You already know which way you will choose. Your soul drew you here |
| [Faculties of the Soul Compared to a Camera Lens](messages/2017/04/2017-04-10-af-james.md) | James | 2017-04-10 | The image of God's Truth is already within you. The only question is whether the iris is open and the lens is clear |
| [Jesus Speaks of the Pentecost](messages/2017/05/2017-05-11-af-jesus.md) | Jesus | 2017-05-11 | The only thing holding you back from the awakening of your soul is you |
| [Accept the Diversity that God Created](messages/2017/05/2017-05-13-af-yogananda.md) | Yogananda | 2017-05-13 | When different souls bring their truth together, they create something more beautiful than any one of them could alone |
| [Allow God to Use You as His Channel of Love](messages/2017/05/2017-05-22-af-andrew.md) | Andrew | 2017-05-22 | When your days are over and you look back, you will see that every step led to the next, and your life was an expression of Light |
| [Lesson on Judgement](messages/2017/06/2017-06-15-af-augustine.md) | Augustine | 2017-06-15 | With Love, I cannot judge. With joy, I cannot judge. With acceptance, I cannot judge |
| [Only the Soul Can Know God's Love](messages/2017/08/2017-08-21-af-matthew.md) | Matthew | 2017-08-21 | A thousand words and a million books will never bring this Truth as it is experienced by that deep Touch from God |
| [The Time Approaches](messages/2017/09/2017-09-12-af-confucius.md) | Confucius | 2017-09-12 | All those years of prayer are about to open doors you have not yet imagined |
| [Release of Limitations](messages/2017/09/2017-09-12-af-augustine.md) | Augustine | 2017-09-12 | There is so much to learn, and yet there is so much to unlearn |
| [Understanding the Laws of Love and the Regeneration of Our Souls](messages/2017/09/2017-09-12-af-martin-luther.md) | Martin Luther | 2017-09-12 | To one whose soul is filled with Love, obeying God's Laws is not a burden. It makes perfect sense |
| [Make Love Your Guiding Truth Through Earth Changes](messages/2017/09/2017-09-13-af-keea-atta-kem.md) | Keea atta Kem | 2017-09-13 | You will be a rock in a world disrupted by change, and the chaos around you will be the very thing that sends people to your door |
| [Choice and Accepting the Will of God](messages/2017/10/2017-10-25-af-yogananda.md) | Yogananda | 2017-10-25 | God will never turn away from you no matter what you decide. But if every invitation is rejected, the invitations will cease |
| [Tesla Talks About the Power of Love](messages/2017/11/2017-11-03-af-nikola-tesla.md) | Nikola Tesla | 2017-11-03 | Love is not just a feeling. It is the most powerful energy in the universe, and its capacities have barely been understood |
| [On Soul Expiation](messages/2017/12/2017-12-12-af-seretta-kem.md) | Seretta Kem | 2017-12-12 | There is always a crack in the armor. God always finds a way through |